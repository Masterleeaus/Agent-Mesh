#!/usr/bin/env python3
"""Build the Titan AI Workforce Pass-11 ecosystem capability snapshot from supplied extension sources.

The snapshot is definition/provenance data only. It never grants authority. Runtime access is
activated only when the provider extension's service-provider class is installed/autoloadable.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import zipfile
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any, Iterable

CANONICAL_PROVIDERS = [
    'crm','titan-ai','titan-ai-core','titan-ai-vision','titan-assets','titan-assurance','titan-autonomy','titan-command-bus',
    'titan-connect','titan-field','titan-financial-engine','titan-forge','titan-governance','titan-interaction-engine',
    'titan-knowledge-authority','titan-ledger','titan-locker','titan-maps-intelligence','titan-mcp','titan-model-council',
    'titan-nexus','titan-prime','titan-rewind','titan-risk-engine','titan-shield','titan-signal-engine','titan-time-attendance','titan-wisdom',
]

ALIASES = {
    'titan-signal': 'titan-signal-engine',
    'titan-signal-engine': 'titan-signal-engine',
    'titan-risk': 'titan-risk-engine',
    'titan-risk-engine': 'titan-risk-engine',
    'titan-ai-assurance': 'titan-assurance',
    'titan-assurance-engine': 'titan-assurance',
    'titan-ai-assurance-engine': 'titan-assurance',
    'titan-assurance': 'titan-assurance',
    'titan-autonomy-engine': 'titan-autonomy',
    'titan-autonomy': 'titan-autonomy',
    'titan-commandbus': 'titan-command-bus',
    'titan-command-bus': 'titan-command-bus',
    'titan-knowledge': 'titan-knowledge-authority',
    'titan-knowledge-authority': 'titan-knowledge-authority',
    'titan-maps': 'titan-maps-intelligence',
    'titan-maps-intelligence': 'titan-maps-intelligence',
    'titan-time-and-attendance': 'titan-time-attendance',
    'titan-time-attendance': 'titan-time-attendance',
}

CATEGORIES = {
    'crm': 'business-domain', 'titan-field': 'business-domain', 'titan-assets': 'business-domain', 'titan-locker': 'business-domain',
    'titan-ledger': 'business-domain', 'titan-financial-engine': 'business-domain', 'titan-connect': 'business-domain',
    'titan-maps-intelligence': 'business-domain', 'titan-time-attendance': 'business-domain', 'titan-knowledge-authority': 'business-domain',
    'titan-ai-vision': 'business-intelligence', 'titan-nexus': 'business-configuration',
    'titan-ai': 'cognition-runtime', 'titan-ai-core': 'cognition-planning', 'titan-model-council': 'cognition-deliberation', 'titan-prime': 'cognition-missions',
    'titan-signal-engine': 'control-plane', 'titan-risk-engine': 'control-plane', 'titan-assurance': 'control-plane', 'titan-governance': 'control-plane',
    'titan-autonomy': 'control-plane', 'titan-command-bus': 'control-plane', 'titan-rewind': 'control-plane', 'titan-wisdom': 'control-plane',
    'titan-shield': 'control-plane', 'titan-interaction-engine': 'platform-runtime', 'titan-mcp': 'platform-operations', 'titan-forge': 'platform-build',
}

# Curated role bindings. These attach real provider surfaces to intrinsic job functions but never grant authority.
ROLE_RULES: dict[str, list[tuple[str, list[str]]]] = {
    'crm': [
        ('titan.customer.receptionist', ['crm.customer.', 'crm.contact.', 'crm.lead.create', 'crm.activity.create', 'crm.company.search']),
        ('titan.customer.booking_coordinator', ['crm.appointment.', 'crm.calendar.', 'crm.business.booking_rules.', 'crm.customer.read', 'crm.customer.search']),
        ('titan.manager.customer_service', ['crm.customer.', 'crm.contact.', 'crm.company.search', 'crm.activity.', 'crm.form.', 'crm.form_submission.', 'crm.form_response.']),
        ('titan.customer.customer_care_coordinator', ['crm.customer.', 'crm.activity.', 'crm.form_response.', 'crm.review.', 'crm.support.']),
        ('titan.manager.sales', ['crm.lead.', 'crm.deal.', 'crm.quote.', 'crm.estimate.', 'crm.company.', 'crm.contact.']),
        ('titan.sales.sales_representative', ['crm.lead.', 'crm.deal.', 'crm.company.search', 'crm.contact.search', 'crm.customer.search']),
        ('titan.sales.quote_coordinator', ['crm.quote.', 'crm.estimate.', 'crm.finance.quote_estimate.', 'crm.finance.pricing.', 'crm.finance.margin_profitability.']),
        ('titan.operations.office_manager', ['crm.business.', 'crm.company.context.read', 'crm.location.', 'crm.custom_field.', 'crm.automation.']),
        ('titan.money.billing_coordinator', ['crm.invoice.', 'crm.credit_note.', 'crm.receivable.']),
        ('titan.money.accounts_receivable_officer', ['crm.invoice.', 'crm.receivable.', 'crm.credit_note.read']),
    ],
    'titan-field': [
        ('titan.manager.service', ['titan.field.']),
        ('titan.work.job_coordinator', ['titan.field.work_orders', 'titan.field.requests', 'titan.field.scheduling', 'titan.field.exceptions', 'titan.field.history']),
        ('titan.work.work_planner', ['titan.field.catalogue', 'titan.field.work_orders', 'titan.field.capacity.forecast', 'titan.field.scheduling', 'titan.field.routes']),
        ('titan.work.scheduler', ['titan.field.scheduling', 'titan.field.scheduling_kernel', 'titan.field.capacity.forecast', 'titan.field.routes']),
        ('titan.work.dispatcher', ['titan.field.dispatch', 'titan.field.scheduling', 'titan.field.routes', 'titan.field.exceptions', 'titan.field.capacity.forecast']),
        ('titan.work.field_coordinator', ['titan.field.work_orders', 'titan.field.forms', 'titan.field.evidence', 'titan.field.routes', 'titan.field.exceptions']),
        ('titan.work.job_completion_coordinator', ['titan.field.evidence', 'titan.field.forms', 'titan.field.evidence_gated_completion', 'titan.field.command_reconciliation']),
        ('titan.work.quality_coordinator', ['titan.field.evidence', 'titan.field.forms', 'titan.field.reviews', 'titan.field.evidence_gated_completion']),
        ('titan.work.maintenance_coordinator', ['titan.field.recurring', 'titan.field.assets', 'titan.field.history', 'titan.field.work_orders']),
        ('titan.work.recurring_services_coordinator', ['titan.field.recurring', 'titan.field.recurring_generation_watermark', 'titan.field.scheduling']),
        ('titan.work.emergency_service_coordinator', ['titan.field.dispatch', 'titan.field.scheduling', 'titan.field.routes', 'titan.field.exceptions']),
    ],
    'titan-assets': [
        ('titan.manager.assets', ['assets.']),
        ('titan.assets.equipment_coordinator', ['assets.equipment', 'assets.tools.', 'assets.allocations', 'assets.location_', 'assets.scan.']),
        ('titan.assets.fleet_coordinator', ['assets.fleet', 'assets.mileage', 'assets.scan.', 'assets.maintenance']),
        ('titan.assets.asset_maintenance_coordinator', ['assets.maintenance', 'assets.lifecycle', 'assets.history', 'assets.scan.maintenance', 'assets.equipment_checks']),
    ],
    'titan-locker': [
        ('titan.assets.inventory_coordinator', ['inventory.items', 'inventory.locations', 'inventory.stock_', 'inventory.reservations', 'inventory.reorder', 'inventory.stock_counts', 'inventory.job_consumption']),
        ('titan.assets.purchasing_officer', ['inventory.suppliers', 'inventory.purchase_orders', 'inventory.goods_receipts', 'inventory.reorder']),
        ('titan.manager.procurement_supply', ['inventory.suppliers', 'inventory.purchase_orders', 'inventory.goods_receipts', 'inventory.reorder']),
        ('titan.procurement.procurement_coordinator', ['inventory.purchase_orders', 'inventory.goods_receipts', 'inventory.suppliers']),
        ('titan.procurement.materials_planner', ['inventory.items', 'inventory.stock_', 'inventory.reorder', 'inventory.reservations']),
    ],
    'titan-ledger': [
        ('titan.manager.finance', ['ledger.']),
        ('titan.money.billing_coordinator', ['ledger.invoice', 'ledger.receiv', 'ledger.journal', 'ledger.tax']),
        ('titan.money.accounts_receivable_officer', ['ledger.receiv', 'ledger.invoice', 'ledger.bank_reconciliation']),
        ('titan.money.accounts_payable_officer', ['ledger.payable', 'ledger.spend', 'ledger.purchase', 'ledger.bank_reconciliation']),
        ('titan.money.bookkeeper', ['ledger.chart_', 'ledger.journal', 'ledger.bank_', 'ledger.reconciliation', 'ledger.accounting_', 'ledger.financial_year', 'ledger.period_']),
        ('titan.money.cost_controller', ['ledger.cost', 'ledger.forecast', 'ledger.reporting', 'ledger.financial_']),
        ('titan.money.credit_disputes_coordinator', ['ledger.receiv', 'ledger.credit', 'ledger.reconciliation']),
    ],
    'titan-financial-engine': [
        ('titan.sales.estimator', ['financial.calculate.quote.estimate', 'financial.calculate.labour.rate', 'financial.calculate.inventory.materials.cost', 'financial.calculate.asset.fleet.equipment.cost', 'financial.calculate.job.costing', 'financial.calculate.pricing', 'financial.calculate.tax']),
        ('titan.sales.quote_coordinator', ['financial.calculate.quote.estimate', 'financial.calculate.pricing', 'financial.calculate.discount.promotion', 'financial.calculate.margin.profitability', 'financial.calculate.tax', 'financial.calculate.recurring.pricing']),
        ('titan.manager.finance', ['financial.calculate.']),
        ('titan.money.cost_controller', ['financial.calculate.job.costing', 'financial.calculate.margin.profitability', 'financial.calculate.forecast.cash.flow', 'financial.calculate.break.even.scenario']),
        ('titan.insights.revenue_analyst', ['financial.calculate.margin.profitability', 'financial.calculate.forecast.cash.flow', 'financial.calculate.break.even.scenario']),
        ('titan.procurement.materials_planner', ['financial.calculate.inventory.materials.cost', 'financial.calculate.procurement.landed.cost']),
        ('titan.assets.fleet_coordinator', ['financial.calculate.asset.fleet.equipment.cost']),
    ],
    'titan-connect': [
        ('titan.customer.receptionist', ['communications.']),
        ('titan.manager.customer_service', ['communications.']),
        ('titan.customer.customer_service_coordinator', ['communications.']),
        ('titan.customer.customer_care_coordinator', ['communications.']),
        ('titan.customer.after_hours_coordinator', ['communications.']),
        ('titan.work.dispatcher', ['communications.team-chat', 'communications.omnichannel', 'communications.voice', 'communications.external.', 'communications.team.']),
        ('titan.operations.executive_assistant', ['communications.']),
    ],
    'titan-maps-intelligence': [
        ('titan.work.dispatcher', ['titan-maps-intelligence.dispatch.', 'titan-maps-intelligence.route.', 'titan-maps-intelligence.travel.', 'titan-maps-intelligence.service-area']),
        ('titan.work.scheduler', ['titan-maps-intelligence.route.', 'titan-maps-intelligence.travel.', 'titan-maps-intelligence.dispatch.']),
        ('titan.work.field_coordinator', ['titan-maps-intelligence.route.', 'titan-maps-intelligence.geocode', 'titan-maps-intelligence.travel.', 'titan-maps-intelligence.territor']),
        ('titan.work.work_planner', ['titan-maps-intelligence.route.', 'titan-maps-intelligence.travel.', 'titan-maps-intelligence.territor', 'titan-maps-intelligence.service-area']),
        ('titan.manager.service', ['titan-maps-intelligence.dispatch.', 'titan-maps-intelligence.territor', 'titan-maps-intelligence.usage']),
    ],
    'titan-time-attendance': [
        ('titan.manager.workforce', ['time.', 'attendance.']),
        ('titan.people.roster_coordinator', ['time.entry.', 'time.submission.', 'time.attention.', 'attendance.']),
        ('titan.people.crew_coordinator', ['time.entry.', 'time.timer.', 'attendance.']),
        ('titan.people.compliance_coordinator', ['attendance.verification.', 'attendance.verify', 'time.policy.read', 'time.attention.read']),
        ('titan.people.health_safety_coordinator', ['attendance.verification.', 'attendance.verify', 'time.attention.read']),
    ],
    'titan-knowledge-authority': [
        ('titan.manager.records_data', ['knowledge.', 'titan-knowledge', 'authority.']),
        ('titan.records.document_controller', ['knowledge.', 'titan-knowledge', 'authority.']),
        ('titan.records.data_governance', ['knowledge.', 'titan-knowledge', 'authority.']),
    ],
    'titan-ai-vision': [
        ('titan.work.quality_coordinator', ['vision.']),
        ('titan.work.field_coordinator', ['vision.']),
        ('titan.work.site_coordinator', ['vision.']),
        ('titan.people.health_safety_coordinator', ['vision.']),
        ('titan.people.compliance_coordinator', ['vision.']),
        ('titan.assets.asset_maintenance_coordinator', ['vision.']),
    ],
    'titan-nexus': [
        ('titan.operations.office_manager', ['nexus.']),
        ('titan.automation.integration_coordinator', ['nexus.']),
        ('titan.records.data_governance', ['nexus.']),
    ],
    'titan-mcp': [
        ('titan.manager.automation', ['titan.mcp.', 'titan-mcp']),
        ('titan.automation.integration_coordinator', ['titan.mcp.', 'titan-mcp']),
        ('titan.automation.workflow_coordinator', ['titan.mcp.runtime.read', 'titan.mcp.read']),
    ],
    'titan-forge': [
        ('titan.manager.automation', ['forge.']),
        ('titan.automation.integration_coordinator', ['forge.']),
        ('titan.automation.automation_quality_coordinator', ['forge.validate.', 'forge.release.']),
    ],
    'titan-interaction-engine': [
        ('titan.operations.chief_of_staff', ['interaction.', 'titan-interaction', 'capability.']),
        ('titan.operations.office_manager', ['interaction.', 'titan-interaction', 'capability.']),
        ('titan.manager.automation', ['interaction.', 'titan-interaction', 'capability.']),
    ],
    'titan-ai': [
        ('titan.manager.automation', ['titan-ai.']),
        ('titan.automation.integration_coordinator', ['titan-ai.']),
    ],
    'titan-ai-core': [
        ('titan.executive.business_manager', ['ai.', 'titan-ai-core']),
        ('titan.manager.operations', ['ai.', 'titan-ai-core']),
        ('titan.manager.business_intelligence', ['ai.', 'titan-ai-core']),
    ],
    'titan-model-council': [
        ('titan.executive.business_manager', ['council.', 'model.', 'titan-model']),
        ('titan.manager.business_intelligence', ['council.', 'model.', 'titan-model']),
    ],
    'titan-prime': [
        ('titan.executive.business_manager', ['prime.', 'mission.', 'titan-prime']),
        ('titan.operations.strategy_coordinator', ['prime.', 'mission.', 'titan-prime']),
    ],
    'titan-shield': [
        ('titan.manager.compliance_governance', ['shield.']),
        ('titan.governance.assurance_coordinator', ['shield.']),
        ('titan.work.quality_coordinator', ['shield.']),
        ('titan.people.health_safety_coordinator', ['shield.']),
    ],
}

CONTROL_PLANE_KEYS = {
    'titan-assurance','titan-autonomy','titan-command-bus','titan-governance','titan-rewind','titan-risk-engine','titan-signal-engine','titan-wisdom'
}

READ_WORDS = ('read','search','list','status','health','inspect','preview','history','report','analytics','overview','context','available','recommend','forecast','calculate','evaluate','lookup','validate','audit','metrics','summary','get','find')
WRITE_WORDS = ('create','update','delete','revoke','rotate','toggle','move','win','lose','submit','issue','void','send','transition','record','link','commit','execute','rollback','fulfill','release','reserve','assign','complete','schedule','approve','cancel','receive','transfer','set','manage','dispatch','apply','store','publish','ingest','verify','resolve','revise','attach','start','stop','open','close','promote','reject','override','write','mutate','reconcile','register')


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding='utf-8'))


def capability_id(value: Any) -> str:
    if isinstance(value, str): return value.strip()
    if isinstance(value, dict):
        for key in ('id','name','key','capability'):
            v = value.get(key)
            if isinstance(v, str) and v.strip(): return v.strip()
    return ''


def op_mode(cap: str) -> str:
    tokens = re.split(r'[._:-]+', cap.lower())
    if any(t in WRITE_WORDS for t in tokens): return 'write'
    if any(t in READ_WORDS for t in tokens): return 'read'
    return 'feature'


def add_cap(caps: dict[str, dict[str, Any]], cap: str, authority: str, source: str, *, description: str | None = None, mode: str | None = None) -> None:
    cap = cap.strip()
    if not cap: return
    rank = {'informational': 0, 'compatibility': 1, 'authoritative': 2}
    row = {'id': cap, 'authority': authority, 'mode': mode or op_mode(cap), 'source': source}
    if description: row['description'] = description
    old = caps.get(cap)
    if old is None or rank[authority] > rank.get(str(old.get('authority')), -1): caps[cap] = row
    elif old is not None:
        sources = sorted(set(([str(old.get('source'))] if old.get('source') else []) + [source]))
        old['source'] = sources[0] if len(sources) == 1 else sources


def extension_meta(root: Path) -> dict[str, Any]:
    ext = load_json(root / 'extension.json') if (root / 'extension.json').exists() else {}
    side = load_json(root / 'extension.manifest.json') if (root / 'extension.manifest.json').exists() else {}
    key = str(ext.get('slug') or side.get('key') or side.get('identity', {}).get('slug') or root.name)
    version = str(ext.get('version') or side.get('version') or side.get('identity', {}).get('version') or '')
    name = str(ext.get('name') or side.get('name') or side.get('identity', {}).get('name') or key)
    provider_class = str(ext.get('provider') or side.get('provider') or side.get('identity', {}).get('provider') or '')
    return {'key': key, 'version': version, 'name': name, 'provider_class': provider_class}


def archive_map(zips_dir: Path) -> dict[str, dict[str, str]]:
    out: dict[str, dict[str, str]] = {}
    for z in zips_dir.glob('*.zip'):
        try:
            with zipfile.ZipFile(z) as zz:
                names = zz.namelist()
                data = None
                for candidate in ['extension.json', 'extension.manifest.json']:
                    if candidate in names:
                        data = json.loads(zz.read(candidate)); break
                if data is None:
                    candidate = next((n for n in names if n.endswith('/extension.json')), None)
                    if candidate: data = json.loads(zz.read(candidate))
                if not isinstance(data, dict): continue
                key = str(data.get('slug') or data.get('key') or data.get('identity', {}).get('slug') or '')
                if key:
                    out[key] = {'filename': z.name, 'sha256': sha256_file(z)}
        except Exception:
            continue
    return out


def evidence(root: Path, paths: Iterable[str]) -> list[dict[str, str]]:
    rows=[]
    for rel in paths:
        p=root/rel
        if p.is_file(): rows.append({'path':rel,'sha256':sha256_file(p)})
    return rows


def extract_capabilities(slug: str, root: Path) -> tuple[list[dict[str, Any]], list[str]]:
    caps: dict[str, dict[str, Any]] = {}
    ev: list[str] = []
    capfile = root / 'CAPABILITIES.json'
    if slug == 'crm' and capfile.exists():
        o=load_json(capfile); ev.append('CAPABILITIES.json')
        for c in o.get('active_core_governed_capabilities', []): add_cap(caps, capability_id(c), 'authoritative', 'CAPABILITIES.json:active_core_governed_capabilities')
        for c in o.get('external_compatibility_capabilities', []): add_cap(caps, capability_id(c), 'compatibility', 'CAPABILITIES.json:external_compatibility_capabilities')
        for c in o.get('feature_capabilities', []): add_cap(caps, capability_id(c), 'informational', 'CAPABILITIES.json:feature_capabilities')
    elif slug == 'titan-field' and capfile.exists():
        o=load_json(capfile); ev.append('CAPABILITIES.json')
        for c in o.get('canonical_capabilities', []): add_cap(caps, capability_id(c), 'authoritative', 'CAPABILITIES.json:canonical_capabilities')
        for c in o.get('capabilities', []): add_cap(caps, capability_id(c), 'compatibility', 'CAPABILITIES.json:capabilities')
    elif slug == 'titan-ledger' and capfile.exists():
        o=load_json(capfile); ev.append('CAPABILITIES.json')
        for c in o.get('capabilities', []):
            cid=capability_id(c); add_cap(caps,cid,'compatibility' if cid.startswith('crm.') else 'authoritative','CAPABILITIES.json:capabilities')
    elif slug == 'titan-locker' and capfile.exists():
        o=load_json(capfile); ev.append('CAPABILITIES.json')
        for c in o.get('capabilities', []):
            cid=capability_id(c); add_cap(caps,cid,'compatibility' if 'legacy_route_compatibility' in cid else 'authoritative','CAPABILITIES.json:capabilities')
    elif slug == 'titan-assets' and capfile.exists():
        o=load_json(capfile); ev.append('CAPABILITIES.json')
        for c in o.get('capabilities', []): add_cap(caps, capability_id(c), 'authoritative', 'CAPABILITIES.json:capabilities')
    elif slug == 'titan-assurance' and (root/'titan-capabilities.json').exists():
        o=load_json(root/'titan-capabilities.json'); ev.append('titan-capabilities.json')
        for c in o.get('capabilities', []): add_cap(caps, capability_id(c), 'authoritative', 'titan-capabilities.json:capabilities')
    elif slug == 'titan-governance' and (root/'release/CAPABILITY-INVENTORY.json').exists():
        o=load_json(root/'release/CAPABILITY-INVENTORY.json'); ev.append('release/CAPABILITY-INVENTORY.json')
        for c in o.get('capabilities', []): add_cap(caps, capability_id(c), 'authoritative', 'release/CAPABILITY-INVENTORY.json:capabilities')
    elif slug == 'titan-financial-engine':
        path=root/'System/Support/EngineCatalog.php'; txt=path.read_text(encoding='utf-8'); ev.append('System/Support/EngineCatalog.php')
        for key in re.findall(r"\n\s*'([a-z0-9_]+)'\s*=>\s*self::assistant\(", txt):
            add_cap(caps, 'financial.calculate.' + key.replace('_','.'), 'authoritative', 'System/Support/EngineCatalog.php:assistants', mode='read')
    else:
        side_path=root/'extension.manifest.json'
        ext_path=root/'extension.json'
        side=load_json(side_path) if side_path.exists() else {}
        raw=side.get('capabilities')
        vals: list[Any] = []
        source=''
        if isinstance(raw,list): vals=raw; source='extension.manifest.json:capabilities'; ev.append('extension.manifest.json')
        elif isinstance(raw,dict) and isinstance(raw.get('provides'),list): vals=raw['provides']; source='extension.manifest.json:capabilities.provides'; ev.append('extension.manifest.json')
        elif ext_path.exists():
            ext=load_json(ext_path); raw=ext.get('capabilities')
            if isinstance(raw,list): vals=raw; source='extension.json:capabilities'; ev.append('extension.json')
        for c in vals: add_cap(caps, capability_id(c), 'authoritative', source)

    # Titan Connect exposes concrete governed message gateway methods in addition to macro capability groups.
    if slug == 'titan-connect':
        extra = [
            ('communications.team.messages.read','read'), ('communications.team.messages.send','write'),
            ('communications.team.conversation.create','write'), ('communications.team.conversation.reply','write'),
            ('communications.external.send','write'),
        ]
        for cid,mode in extra: add_cap(caps,cid,'authoritative','System/Contracts/MessagingToolGateway.php',mode=mode)
        ev.append('System/Contracts/MessagingToolGateway.php')

    return sorted(caps.values(), key=lambda x:x['id']), sorted(set(ev))


def normalize_tool(row: dict[str, Any], source: str) -> dict[str, Any] | None:
    tid = str(row.get('id') or row.get('tool_id') or row.get('name') or '').strip()
    if not tid: return None
    mode = str(row.get('mode') or 'provider_defined').lower()
    out={'id':tid,'mode':mode,'source':source}
    cap=str(row.get('capability') or '').strip()
    if cap: out['capability']=cap
    for k in ('risk','description','requires_approval','authorization'):
        if k in row: out[k]=row[k]
    return out


def extract_tools(slug: str, root: Path) -> tuple[list[dict[str, Any]], list[str]]:
    tools: dict[str, dict[str, Any]]={}; ev=[]
    wf=root/'resources/workforce/workforce-manifest.json'
    if wf.exists():
        o=load_json(wf)
        for row in o.get('tools',[]):
            if isinstance(row,dict):
                t=normalize_tool(row,'resources/workforce/workforce-manifest.json:tools')
                if t: tools[t['id']]=t
        if o.get('tools'): ev.append('resources/workforce/workforce-manifest.json')
    if slug=='crm':
        p=root/'System/Integrations/TitanAI/CrmTitanAIToolProvider.php'
        if p.exists():
            txt=p.read_text(encoding='utf-8'); ev.append(str(p.relative_to(root)))
            for label,mode in [('READS','read'),('WRITES','write')]:
                m=re.search(r'private const '+label+r'\s*=\s*\[(.*?)\];',txt,re.S)
                if m:
                    for cid in re.findall(r"'([^']+)'",m.group(1)):
                        tools[cid]={'id':cid,'capability':cid,'mode':mode,'source':str(p.relative_to(root))+':'+label}
        p=root/'System/AI/Tools/CrmToolRegistry.php'
        if p.exists():
            txt=p.read_text(encoding='utf-8'); ev.append(str(p.relative_to(root)))
            for name,mode,desc in re.findall(r"\['name'=>'([^']+)','mode'=>'([^']+)','description'=>'([^']*)'\]",txt):
                tools[name]={'id':name,'mode':mode,'description':desc,'source':str(p.relative_to(root))+':tools'}
    elif slug=='titan-connect':
        p=root/'System/Contracts/MessagingToolGateway.php'; ev.append(str(p.relative_to(root)))
        mapping={
            'messagesRead':('communications.team.messages.read','read'),
            'messagesSend':('communications.team.messages.send','write'),
            'conversationCreate':('communications.team.conversation.create','write'),
            'conversationReply':('communications.team.conversation.reply','write'),
            'externalSend':('communications.external.send','write'),
        }
        for method,(cap,mode) in mapping.items(): tools['connect.'+re.sub(r'(?<!^)(?=[A-Z])','-',method).lower()]={'id':'connect.'+re.sub(r'(?<!^)(?=[A-Z])','-',method).lower(),'capability':cap,'mode':mode,'source':str(p.relative_to(root))}
    elif slug=='titan-financial-engine':
        p=root/'System/Support/EngineCatalog.php'; txt=p.read_text(encoding='utf-8'); ev.append(str(p.relative_to(root)))
        for key in re.findall(r"\n\s*'([a-z0-9_]+)'\s*=>\s*self::assistant\(",txt):
            cap='financial.calculate.'+key.replace('_','.')
            tools['financial.engine.'+key.replace('_','-')]={'id':'financial.engine.'+key.replace('_','-'),'capability':cap,'mode':'read','source':str(p.relative_to(root))+':assistants'}
    elif slug=='titan-maps-intelligence':
        for p in sorted((root/'Tools').glob('*Tool.php')):
            txt=p.read_text(encoding='utf-8')
            caps=re.findall(r"authorize\([^;]*?'([^']+)'\)",txt,re.S)
            cap=caps[0] if caps else ''
            stem=re.sub(r'Tool$','',p.stem)
            tid='maps.'+re.sub(r'(?<!^)(?=[A-Z])','-',stem).lower()
            mode='write' if any(w in stem.lower() for w in ('update','manage','approve','reject','promote','cancel','start','override')) else 'read'
            row={'id':tid,'mode':mode,'source':str(p.relative_to(root))}
            if cap: row['capability']=cap
            tools[tid]=row; ev.append(str(p.relative_to(root)))
    elif slug=='titan-ai':
        for p in sorted((root/'System/AI/Tier4/Tools').glob('*Tool.php')):
            txt=p.read_text(encoding='utf-8')
            mid=re.search(r"function id\(\): string \{ return '([^']+)'",txt)
            if not mid: continue
            tid=mid.group(1); approval="requiresApproval(): bool { return true" in txt
            perms=[]
            mp=re.search(r'function permissions\(\): array \{ return \[(.*?)\]; \}',txt,re.S)
            if mp: perms=re.findall(r"'([^']+)'",mp.group(1))
            tools[tid]={'id':tid,'mode':'write' if approval else 'read','requires_approval':approval,'required_permissions':perms,'source':str(p.relative_to(root))}
            ev.append(str(p.relative_to(root)))
    elif slug=='titan-mcp':
        p=root/'System/Mcp/Support/McpCatalogue.php'; txt=p.read_text(encoding='utf-8'); ev.append(str(p.relative_to(root)))
        pat=re.compile(r"self::(read|write|coordinate)\('([^']+)',\s*'([^']*)',\s*'([^']*)',\s*'([^']+)'",re.S)
        for mode,name,title,desc,cap in pat.findall(txt):
            tools[name]={'id':name,'capability':cap,'mode':'read' if mode=='read' else 'write','description':desc,'source':str(p.relative_to(root))+':tools'}
    return sorted(tools.values(), key=lambda x:x['id']), sorted(set(ev))


def extract_signals(slug: str, root: Path) -> tuple[list[dict[str, Any]], list[str]]:
    signals: dict[str, dict[str, Any]]={}; ev=[]
    wf=root/'resources/workforce/workforce-manifest.json'
    if wf.exists():
        o=load_json(wf)
        rows=[]
        if isinstance(o.get('signals'),list): rows += o['signals']
        if isinstance(o.get('signal_subscriptions'),list): rows += o['signal_subscriptions']
        for row in rows:
            if isinstance(row,str): sid=row
            elif isinstance(row,dict): sid=str(row.get('signal') or row.get('event') or row.get('id') or '')
            else: sid=''
            if sid: signals[sid]={'id':sid,'event_type':sid,'source':'resources/workforce/workforce-manifest.json'}
        if rows: ev.append('resources/workforce/workforce-manifest.json')
    doc=root/'docs/SIGNAL-EVENTS.md'
    if doc.exists():
        txt=doc.read_text(encoding='utf-8',errors='ignore'); ev.append(str(doc.relative_to(root)))
        for token in re.findall(r'`([^`]+)`',txt):
            token=token.strip()
            if not re.fullmatch(r'[a-z][a-z0-9_.-]{3,120}',token): continue
            if '/' in token or token.endswith(('.json','.php','.md')): continue
            if token in {'trace_id','correlation_id','causation_id','root_causation_id','receipt_id','receipt_hash','tenant_company_id','company_id','idempotency_key','source_component','expected_resolution_at'}: continue
            # Event names almost always have a lifecycle verb; avoid capability/contract tokens.
            if not any(v in token for v in ('.created','.updated','.completed','.failed','.requested','.recorded','.detected','.opened','.closed','.decided','.started','.queued','.verified','.applied','.blocked','.acknowledged','.suppressed','.resolved','.reopened','.crossed','.increased','.redriven','.status_changed','.generated','.observed','.held')): continue
            signals[token]={'id':token,'event_type':token,'source':str(doc.relative_to(root))}
    return sorted(signals.values(),key=lambda x:x['id']), sorted(set(ev))


def extract_workflows(slug: str, root: Path) -> tuple[list[dict[str, Any]], list[str]]:
    wf=root/'resources/workforce/workforce-manifest.json'
    out=[]; ev=[]
    if wf.exists():
        o=load_json(wf)
        for row in o.get('workflows',[]):
            if not isinstance(row,dict): continue
            item=dict(row)
            wid=str(item.get('id') or item.get('workflow_id') or '').strip()
            if not wid: continue
            item['id']=wid; item['source']='resources/workforce/workforce-manifest.json:workflows'; out.append(item)
        if out: ev.append('resources/workforce/workforce-manifest.json')
    return sorted(out,key=lambda x:x['id']),ev


def surfaces_from_capabilities(caps: list[dict[str, Any]], tools: list[dict[str, Any]]) -> tuple[list[dict[str, Any]],list[dict[str, Any]]]:
    commands: dict[str,dict[str,Any]]={}; reads: dict[str,dict[str,Any]]={}
    for cap in caps:
        if cap.get('authority') != 'authoritative': continue
        mode=str(cap.get('mode') or '')
        cid=str(cap['id'])
        if mode=='write': commands[cid]={'id':cid,'capability':cid,'source':'capability-classification','writes_state':True}
        elif mode=='read': reads[cid]={'id':cid,'capability':cid,'source':'capability-classification','access':'read_or_calculate'}
    for tool in tools:
        tid=str(tool['id']); cap=str(tool.get('capability') or '')
        if tool.get('mode')=='write': commands['tool:'+tid]={'id':'tool:'+tid,'tool_id':tid,'capability':cap or None,'source':tool.get('source'),'writes_state':True}
        elif tool.get('mode')=='read': reads['tool:'+tid]={'id':'tool:'+tid,'tool_id':tid,'capability':cap or None,'source':tool.get('source'),'access':'read_or_calculate'}
    return sorted(commands.values(),key=lambda x:x['id']), sorted(reads.values(),key=lambda x:x['id'])


def cap_matches(cap: str, patterns: list[str]) -> bool:
    for pat in patterns:
        if pat.endswith('*') and cap.startswith(pat[:-1]): return True
        if pat.endswith('.') and cap.startswith(pat): return True
        if pat in cap: return True
    return False


def build_role_bindings(slug: str, caps: list[dict[str, Any]], tools: list[dict[str, Any]], commands: list[dict[str, Any]], signals: list[dict[str, Any]], reads: list[dict[str, Any]], workflows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rules=ROLE_RULES.get(slug,[])
    authoritative=[str(c['id']) for c in caps if c.get('authority')=='authoritative']
    tool_by_cap: dict[str,list[str]]={}
    for t in tools:
        cap=str(t.get('capability') or '')
        if cap: tool_by_cap.setdefault(cap,[]).append(str(t['id']))
    cmd_by_cap: dict[str,list[str]]={}
    for c in commands:
        cap=str(c.get('capability') or '')
        if cap: cmd_by_cap.setdefault(cap,[]).append(str(c['id']))
    read_by_cap: dict[str,list[str]]={}
    for d in reads:
        cap=str(d.get('capability') or '')
        if cap: read_by_cap.setdefault(cap,[]).append(str(d['id']))
    out=[]
    for role,patterns in rules:
        selected=sorted(c for c in authoritative if cap_matches(c,patterns))
        if not selected: continue
        tool_ids=sorted({tid for c in selected for tid in tool_by_cap.get(c,[])})
        command_ids=sorted({cid for c in selected for cid in cmd_by_cap.get(c,[])})
        data_ids=sorted({did for c in selected for did in read_by_cap.get(c,[])})
        # Domain signals/workflows are attached to the roles responsible for that provider's work.
        signal_ids=[str(s['id']) for s in signals]
        workflow_ids=[str(w['id']) for w in workflows]
        out.append({
            'role_definition_id':role,'capabilities':selected,'tools':tool_ids,'commands':command_ids,
            'signals':signal_ids,'data_sources':data_ids,'workflows':workflow_ids,'authority_inherited':False,
            'source':'pass11_ecosystem_registry',
        })
    return out


def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument('providers_dir', type=Path)
    ap.add_argument('provider_zips_dir', type=Path)
    ap.add_argument('output_json', type=Path)
    ap.add_argument('aliases_json', type=Path)
    ap.add_argument('--generated-at', default='')
    args=ap.parse_args()
    providers_dir=args.providers_dir.resolve(); zips=args.provider_zips_dir.resolve()
    archive=archive_map(zips)
    generated_at=args.generated_at or datetime.now(timezone(timedelta(hours=10))).replace(microsecond=0).isoformat()
    rows=[]
    for slug in CANONICAL_PROVIDERS:
        root=providers_dir/slug
        if not root.is_dir(): raise SystemExit(f'missing canonical provider source: {slug}')
        meta=extension_meta(root)
        if meta['key'] != slug: raise SystemExit(f'provider identity mismatch: expected {slug}, found {meta["key"]}')
        if not meta['provider_class']: raise SystemExit(f'provider class missing for {slug}')
        caps,cap_ev=extract_capabilities(slug,root)
        tools,tool_ev=extract_tools(slug,root)
        signals,sig_ev=extract_signals(slug,root)
        workflows,wf_ev=extract_workflows(slug,root)
        commands,reads=surfaces_from_capabilities(caps,tools)
        role_bindings=build_role_bindings(slug,caps,tools,commands,signals,reads,workflows)
        arc=archive.get(slug)
        if not arc: raise SystemExit(f'source archive not found for {slug}')
        evpaths=sorted(set(['extension.json'] + (['extension.manifest.json'] if (root/'extension.manifest.json').exists() else []) + cap_ev+tool_ev+sig_ev+wf_ev))
        provider_aliases=sorted(k for k,v in ALIASES.items() if v==slug and k!=slug)
        rows.append({
            'extension':{'key':slug,'name':meta['name'],'version':meta['version'],'provider_class':meta['provider_class'],'aliases':provider_aliases},
            'category':CATEGORIES.get(slug,'platform'),
            'provenance':{'archive_filename':arc['filename'],'archive_sha256':arc['sha256'],'evidence':evidence(root,evpaths)},
            'ownership':{'organisation_owner':'titan-ai-workforce','provider_owns_execution_surfaces':True,'role_definitions_owned_by_provider':False},
            'runtime':{'availability_requires_installed_provider':True,'availability_probe':{'type':'class_exists','class':meta['provider_class']},'catalogue_grants_authority':False},
            'capabilities':caps,'tools':tools,'commands':commands,'signals':signals,'data_sources':reads,'workflows':workflows,'role_bindings':role_bindings,
            'metadata':{'control_plane_provider':slug in CONTROL_PLANE_KEYS,'step11_catalogue_only_when_not_installed':True},
        })
    unique_caps={(p['extension']['key'],c['id']) for p in rows for c in p['capabilities']}
    auth_caps={(p['extension']['key'],c['id']) for p in rows for c in p['capabilities'] if c['authority']=='authoritative'}
    compat_caps={(p['extension']['key'],c['id']) for p in rows for c in p['capabilities'] if c['authority']=='compatibility'}
    tool_count=sum(len(p['tools']) for p in rows); command_count=sum(len(p['commands']) for p in rows); signal_count=sum(len(p['signals']) for p in rows); workflow_count=sum(len(p['workflows']) for p in rows)
    catalogue={
        'schema_version':'1.0','generated_at':generated_at,'organisation_owner':'titan-ai-workforce','tenant_key':'company_id',
        'source_bundles':['Extensions (1).zip','Extensions2.zip'],
        'safety':{'catalogue_does_not_grant_authority':True,'runtime_activation_requires_installed_provider':True,'authority_inherited':False,'control_plane_execution_wiring_deferred_to_pass12':True},
        'summary':{'provider_count':len(rows),'provider_qualified_capability_count':len(unique_caps),'authoritative_capability_count':len(auth_caps),'compatibility_capability_count':len(compat_caps),'tool_count':tool_count,'command_count':command_count,'signal_count':signal_count,'data_source_count':sum(len(p['data_sources']) for p in rows),'workflow_count':workflow_count,'role_binding_count':sum(len(p['role_bindings']) for p in rows)},
        'providers':rows,
    }
    args.output_json.parent.mkdir(parents=True,exist_ok=True)
    args.output_json.write_text(json.dumps(catalogue,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    aliasdoc={'schema_version':'1.0','canonical_provider_count':28,'aliases':dict(sorted(ALIASES.items())),'rule':'aliases resolve provider identity only; they never transfer capability authority'}
    args.aliases_json.write_text(json.dumps(aliasdoc,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(json.dumps(catalogue['summary'],indent=2))
    return 0

if __name__=='__main__': raise SystemExit(main())
