# Pass 2 — Installer 1.7.8 Root Manifest & Flat ZIP Certification

Plan ID: `321ccd8b-8b54-4fe8-921f-acd184474d03`

Version: `0.8.0-alpha.8`

## Scope

This pass changes deployment metadata and packaging only. Workforce runtime behaviour, role discovery, task semantics, hierarchy, queues, handoffs and business-action governance are intentionally unchanged.

## Installer 1.7.8 root contract

The root `extension.json` is now installer-only and contains exactly:

- `schema`
- `slug`
- `folder`
- `provider`
- `version`
- `integrity.files`

`integrity.files` hashes every regular package file except `extension.json`. The exclusion is mandatory to prevent self-hash recursion.

The authoritative rich architectural sidecar remains `extension.manifest.json`, now materialised as canonical Titan Manifest `schema_version: 2.2` with the `workforce-extension` profile and `titan.production.core.v1` inheritance.

## Workforce contract boundary

This pass does **not** upgrade contributed Workforce manifests. The central runtime still consumes the existing v1 Workforce definition contract. Workforce Manifest 2.0 discovery/normalisation is Pass 3.

Domain extensions remain authoritative owners of their Managers, Specialists, Action Workers, tools, playbooks, workflows and proactive responsibilities. Titan AI Workforce remains authoritative only for instantiated organisational state, tasks, reviews, handoffs and planning.

## Packaging tools

- `tools/build_installer_manifest.py` — creates the exact Installer 1.7.8 root manifest and non-circular integrity set.
- `tools/build_step10_package.py` — creates a flat POSIX ZIP with no outer extension directory.
- `tools/verify_zip.py` — verifies flat-root shape, path safety, CRC and exact `integrity.files` coverage.
- `schemas/titan-installer-manifest.schema.json` — local copy of the Step-10 installer schema used by the manifest builder.

## Invariants

- exact folder casing: `TitanAIWorkforce`
- exact provider: `App\\Extensions\\TitanAIWorkforce\\System\\TitanAIWorkforceServiceProvider`
- no outer ZIP wrapper
- no Windows/backslash ZIP paths
- no absolute or traversal paths
- no symlinks
- no `.DS_Store`, `__MACOSX`, `__pycache__`, `.git` or `node_modules`
- `extension.json` excluded from its own integrity set
- all other regular files included exactly once
