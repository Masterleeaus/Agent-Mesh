# Step 02 — Employee 360° Profile

The Team Center now opens a dedicated company-scoped workspace for every Workforce employee.

## Tabs
Overview, Responsibilities, Work, Capabilities, Tools, Schedule, Delegations, Escalations, Performance, Outcomes, Runtime, History.

## Signature capability-reality contract
The profile makes three different facts visible and never conflates them:

1. **Bound / Can do** — capability is part of the employee's canonical role/provider composition.
2. **Available** — the exact provider surface is live now after provider and company policy evaluation.
3. **Authorized / Allowed to do** — Titan Autonomy has made a task/context-specific decision. No decision is displayed as `—`, never as permission.

Binding and availability do not inherit or grant execution authority. Consequential actions still require the governed Risk → Assurance → Governance → Autonomy → Command Bus path.

## Data coverage
The read-only Employee 360 projection includes canonical responsibilities, assigned/managed work, capability/provider state, tools, schedules, delegations, escalations, performance metrics, verified/observed outcomes, runtime profile and immutable task history. All persistent reads are scoped by canonical `company_id`.
