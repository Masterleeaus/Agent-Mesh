# Pass 11 — Full Ecosystem Capability Registry

Pass 11 normalises the real supplied Titan extension surfaces into a Workforce-owned catalogue. The catalogue is **descriptive only** until the owning provider class is installed; catalogue presence never grants authority.

## Ownership boundary

- Titan AI Workforce owns organisation, divisions, teams, roles and responsibilities.
- Each provider owns its capabilities, tools, commands, signals, data sources and workflows.
- Runtime availability requires the declared provider class to be installed.
- Role bindings only describe availability and always carry `authority_inherited=false`.
- Risk, Assurance, Governance and Autonomy remain mandatory for consequential execution.

## Normalised providers

| Provider | Version | Capabilities | Tools | Commands | Signals | Data sources | Workflows | Role bindings |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `crm` | `1.3.0-alpha.37` | 380 | 38 | 93 | 0 | 60 | 0 | 10 |
| `titan-ai` | `1.5.2` | 11 | 25 | 12 | 0 | 15 | 0 | 2 |
| `titan-ai-core` | `0.5.0` | 9 | 0 | 0 | 0 | 3 | 0 | 3 |
| `titan-ai-vision` | `1.12.0` | 32 | 0 | 0 | 0 | 2 | 0 | 6 |
| `titan-assets` | `0.2.0-alpha.2` | 45 | 0 | 6 | 0 | 5 | 0 | 4 |
| `titan-assurance` | `2.3.0` | 3 | 0 | 1 | 4 | 1 | 0 | 0 |
| `titan-autonomy` | `1.6.0` | 9 | 0 | 5 | 0 | 3 | 0 | 0 |
| `titan-command-bus` | `0.2.0-alpha.6` | 4 | 0 | 1 | 0 | 2 | 0 | 0 |
| `titan-connect` | `0.10.6` | 13 | 5 | 8 | 0 | 3 | 0 | 7 |
| `titan-field` | `1.0.6` | 53 | 14 | 1 | 2 | 11 | 2 | 11 |
| `titan-financial-engine` | `0.4.0` | 17 | 17 | 0 | 0 | 34 | 0 | 7 |
| `titan-forge` | `0.9.0-alpha.1` | 18 | 0 | 3 | 7 | 4 | 0 | 3 |
| `titan-governance` | `1.0.0-rc.2` | 27 | 0 | 2 | 1 | 17 | 0 | 0 |
| `titan-interaction-engine` | `10.3.2` | 23 | 0 | 0 | 0 | 0 | 0 | 3 |
| `titan-knowledge-authority` | `0.5.0-alpha.4` | 2 | 0 | 0 | 0 | 1 | 0 | 3 |
| `titan-ledger` | `1.20.0-rc.5` | 105 | 0 | 7 | 0 | 11 | 0 | 7 |
| `titan-locker` | `1.1.0-alpha.6` | 12 | 0 | 0 | 0 | 0 | 0 | 5 |
| `titan-maps-intelligence` | `2.0.2` | 44 | 44 | 24 | 0 | 56 | 0 | 5 |
| `titan-mcp` | `1.5.8` | 36 | 34 | 21 | 0 | 38 | 0 | 2 |
| `titan-model-council` | `1.0.0-rc.1` | 29 | 0 | 1 | 4 | 2 | 0 | 2 |
| `titan-nexus` | `1.0.0-rc.2` | 28 | 0 | 2 | 3 | 6 | 0 | 3 |
| `titan-prime` | `0.4.0` | 16 | 0 | 0 | 0 | 0 | 0 | 2 |
| `titan-rewind` | `1.0.6` | 44 | 0 | 0 | 9 | 3 | 0 | 0 |
| `titan-risk-engine` | `1.0.0-rc.3` | 7 | 0 | 0 | 5 | 0 | 0 | 0 |
| `titan-shield` | `1.0.0-rc.2` | 9 | 0 | 0 | 4 | 5 | 0 | 4 |
| `titan-signal-engine` | `0.20.0-rc.8.1` | 16 | 0 | 1 | 8 | 2 | 0 | 0 |
| `titan-time-attendance` | `0.1.1` | 14 | 18 | 14 | 16 | 17 | 4 | 5 |
| `titan-wisdom` | `0.3.0` | 7 | 0 | 4 | 0 | 2 | 0 | 0 |

## Registry totals

- **Provider Count:** 28
- **Provider Qualified Capability Count:** 1013
- **Authoritative Capability Count:** 731
- **Compatibility Capability Count:** 155
- **Tool Count:** 195
- **Command Count:** 206
- **Signal Count:** 63
- **Data Source Count:** 303
- **Workflow Count:** 6
- **Role Binding Count:** 94

## Runtime gating

`WorkforceEcosystemCapabilityRegistry::installedContributions()` checks `class_exists()` for each provider service-provider class before its catalogue surfaces are allowed into `WorkforceCapabilityBindingRegistry`. This prevents a complete static ecosystem catalogue from creating phantom access when a provider is not installed.

## Provenance

Every provider row records the SHA-256 of the exact source-preserved provider ZIP used to construct this registry. `tools/build_ecosystem_capability_registry.py` deterministically regenerates the registry from those source packages.

## Compatibility

Existing Workforce Manifest 2.0 provider contributions are merged with the normalized catalogue only after installation. Manifest role blocks remain compatibility binding hints and cannot redefine canonical Workforce employees. Provider aliases are normalized through `resources/workforce/ecosystem-provider-aliases.json`.
