# Pass 1 — Blueprint v4 / Step-10 Baseline Conformance

PLAN_ID: `321ccd8b-8b54-4fe8-921f-acd184474d03`

This pass freezes the current Titan AI Workforce public surface before Installer/Manifest/Workforce contract migrations begin. It does **not** claim v0.6.1 already satisfies Manifest v2.2 or Workforce Manifest v2.0. Those gaps are deliberately recorded for Passes 2 and 3.

## Locked architecture

- Production core target: `titan.production.core.v1`
- Primary profile: `workforce-extension`
- Central Workforce may not use the `workforce-aware` modifier.
- Capability-owning extensions remain the source of truth for roles, Action Workers, tools, workflows, playbooks and proactive responsibilities.
- Titan AI Workforce owns discovery, instantiated organisational state, hierarchy, tasks, queues, reviews, handoffs, planning and Control Room.

## Current known contract gaps

1. `extension.manifest.json` is still schema `1.0`; canonical target is `2.2`.
2. Central Workforce discovery metadata still reports Workforce contract `1.0`; canonical target is `2.0`.
3. Root `extension.json` is close to Installer 1.7.8 identity format but still carries legacy rich fields and legacy integrity shape; Pass 2 will materialize the exact installer contract.
4. Step-10 self-healing menus-table navigation and host authorization adapter are intentionally deferred to their planned passes.

## Machine-readable evidence

- `docs/BLUEPRINT-STEP10-BASELINE-CONFORMANCE.json`
- `docs/PUBLIC-COMPATIBILITY-INVARIANTS.json`
- `docs/RUNTIME-DEPENDENCY-CLASSIFICATION.json`

No domain Workforce role or Action Worker catalogue is bundled centrally.
