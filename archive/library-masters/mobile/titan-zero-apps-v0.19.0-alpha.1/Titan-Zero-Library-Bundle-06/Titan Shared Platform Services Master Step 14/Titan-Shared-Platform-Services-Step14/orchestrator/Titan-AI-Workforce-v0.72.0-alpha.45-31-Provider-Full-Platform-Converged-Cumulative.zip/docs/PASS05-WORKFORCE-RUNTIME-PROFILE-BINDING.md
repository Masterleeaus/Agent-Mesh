# Coordinated Pass 5 — Workforce Member ↔ Runtime Profile Binding

PLAN_ID: `6bb234ac-d390-4a3f-8be2-666f5dec8a81`

Titan AI Workforce is the sole authority that binds an AI employee to an intelligence runtime profile. Runtime profiles are company-scoped persisted policy records and are not business-authority records.

Each active Workforce member receives a stable `runtime_profile_id`. Tasks inherit the assignee profile and cannot replace it. The resolved profile is sent through `titan.agent-runtime/1` as configuration metadata; Titan Agent Runtime must consume that exact profile and may not silently select a default.

Profile fields include persona/system prompt, provider/model policy, memory policy, channel behaviour, informational tools and reasoning configuration. Informational tool declarations do not grant consequential execution authority. Consequential business actions remain governed Workforce/Command Bus capabilities.

Existing members are backfilled additively with proposal-only profiles and zero tools. The migration does not increase authority.
