# Coordinated Pass 3 — Runtime Contract Layer

PLAN_ID: `6bb234ac-d390-4a3f-8be2-666f5dec8a81`

Titan AI Workforce now owns the orchestration-facing `AgentRuntimeContract` and the versioned wire protocol `titan.agent-runtime/1`. `WorkforceAIRuntimeBridge` calls the contract rather than a concrete Agents implementation. Pass 3 preserves existing Titan AI behavior behind `LegacyTitanAIRuntimeAdapter`; a fail-closed implementation is available when no runtime exists.

The contract carries canonical `company_id`, Workforce member/task identity and full runtime lineage. Runtime output is non-authoritative. Tool calls are proposals with `requires_governance=true` and `execution_claimed=false`. No consequential business execution is granted by this pass.
