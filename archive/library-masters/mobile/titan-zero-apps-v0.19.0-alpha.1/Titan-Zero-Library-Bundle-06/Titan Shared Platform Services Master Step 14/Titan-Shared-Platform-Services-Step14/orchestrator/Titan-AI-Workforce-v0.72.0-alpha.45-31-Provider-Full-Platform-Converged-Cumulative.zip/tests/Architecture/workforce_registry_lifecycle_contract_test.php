<?php

declare(strict_types=1);

require_once __DIR__ . '/../../System/Support/WorkforceDefinitionCompatibility.php';

use App\Extensions\TitanAIWorkforce\System\Support\WorkforceDefinitionCompatibility;

function fail_lifecycle(string $message): never { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); }
function ok_lifecycle(bool $condition, string $message): void { if (! $condition) fail_lifecycle($message); }

$root = dirname(__DIR__, 2);

$old = [
    'role_id' => 'titan.example.coordinator',
    'owner_extension' => 'example-domain',
    'tier' => 2,
    'division' => 'example',
    'team' => 'example.ops',
    'capabilities' => ['example.read', 'example.prepare'],
    'tool_access' => ['example.read', 'example.prepare'],
    'workflow_refs' => ['example.standard'],
    'risk_ceiling' => 'MEDIUM',
];

$identical = $old;
$result = WorkforceDefinitionCompatibility::compare($old, $identical);
ok_lifecycle($result['classification'] === 'IDENTICAL', 'identical role definition must remain IDENTICAL');

$compatible = $old;
$compatible['capabilities'][] = 'example.extra';
$compatible['tool_access'][] = 'example.extra';
$result = WorkforceDefinitionCompatibility::compare($old, $compatible);
ok_lifecycle($result['classification'] === 'COMPATIBLE', 'additive capability/tool change must be compatible');
ok_lifecycle($result['requires_explicit_rebind'] === true, 'compatible definition update must still require explicit rebind');

$breaking = $old;
$breaking['capabilities'] = ['example.read'];
$result = WorkforceDefinitionCompatibility::compare($old, $breaking);
ok_lifecycle($result['classification'] === 'BREAKING', 'capability removal must be breaking');
ok_lifecycle(in_array('capabilities_removed', $result['reasons'], true), 'breaking result must explain capability removal');

$renamedOwner = $old;
$renamedOwner['owner_extension'] = 'different-domain';
$result = WorkforceDefinitionCompatibility::compare($old, $renamedOwner);
ok_lifecycle($result['classification'] === 'BREAKING', 'owner change must be breaking and never remapped by role name');

$missing = WorkforceDefinitionCompatibility::missing($old);
ok_lifecycle($missing['classification'] === 'MISSING', 'missing extension definition must become MISSING');
ok_lifecycle($missing['available_for_assignment'] === false, 'missing definition must not remain assignable');

$migration = (string) file_get_contents($root . '/database/migrations/2026_08_18_000004_add_workforce_definition_lifecycle_fields.php');
foreach (['role_owner_extension','role_owner_extension_version','role_definition_version','role_definition_fingerprint','role_definition_state','role_definition_snapshot','role_definition_deprecated_at','role_definition_grace_until'] as $column) {
    ok_lifecycle(str_contains($migration, $column), "member/task lifecycle migration missing {$column}");
}

$member = (string) file_get_contents($root . '/System/Models/WorkforceMember.php');
ok_lifecycle(str_contains($member, "'role_definition_snapshot' => 'array'"), 'member must cast definition snapshot');
ok_lifecycle(str_contains($member, "'role_definition_deprecated_at' => 'datetime'"), 'member must cast deprecation timestamp');

$task = (string) file_get_contents($root . '/System/Models/WorkforceTask.php');
ok_lifecycle(str_contains($task, "'role_definition_snapshot' => 'array'"), 'task must retain immutable role-definition snapshot');

$lifecycle = (string) file_get_contents($root . '/System/Services/WorkforceManifestLifecycleService.php');
foreach (['onActivated', 'onUpgraded', 'onDisabled', 'onUninstalled', 'reconcileExtension', 'MISSING', 'BREAKING', 'COMPATIBLE'] as $needle) {
    ok_lifecycle(str_contains($lifecycle, $needle), "lifecycle service missing {$needle}");
}
ok_lifecycle(str_contains($lifecycle, 'where(\'role_owner_extension\', $extensionKey)'), 'lifecycle reconciliation must match exact owner extension');
ok_lifecycle(! str_contains($lifecycle, "where('role',"), 'lifecycle reconciliation must never remap by display role name');

$registry = (string) file_get_contents($root . '/System/Support/WorkforceManifestRegistry.php');
foreach (['suppressExtension', 'restoreExtension', 'findOwnedRole', 'invalidateExtension'] as $method) {
    ok_lifecycle(str_contains($registry, "function {$method}"), "manifest registry missing lifecycle method {$method}");
}

$memberLifecycle = (string) file_get_contents($root . '/System/Services/WorkforceMemberLifecycleService.php');
ok_lifecycle(str_contains($memberLifecycle, 'pinFieldsForRole($definition)'), 'staff activation must pin the exact extension-owned definition contract');

$taskService = (string) file_get_contents($root . '/System/Services/WorkforceTaskService.php');
ok_lifecycle(str_contains($taskService, 'pinRoleDefinition'), 'task creation must pin role definition provenance');

$provider = (string) file_get_contents($root . '/System/TitanAIWorkforceServiceProvider.php');
ok_lifecycle(str_contains($provider, "'titan.workforce.manifest-lifecycle'"), 'stable lifecycle adapter binding missing');
foreach (['titan.extension.activated','titan.extension.upgraded','titan.extension.disabled','titan.extension.uninstalled'] as $event) {
    ok_lifecycle(str_contains($provider, $event), "provider missing lifecycle event listener {$event}");
}

$sidecar = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, flags: JSON_THROW_ON_ERROR);
ok_lifecycle(in_array('titan-workforce.manifest-lifecycle', $sidecar['capabilities'] ?? [], true), 'sidecar must expose manifest-lifecycle capability');

$docs = (string) file_get_contents($root . '/docs/PASS04-EXTENSION-WORKFORCE-REGISTRY-LIFECYCLE.md');
ok_lifecycle(str_contains($docs, 'Historical tasks are never deleted'), 'Pass 4 docs must preserve history explicitly');

fwrite(STDOUT, "PASS: Titan AI Workforce extension-owned registry lifecycle contract\n");
