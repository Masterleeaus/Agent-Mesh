# Pass 3 — Workforce Manifest 2.0 Registry & Legacy Normalisation

Version: `0.9.0-alpha.9`

## Implemented

- Replaced the central Workforce 1.0 schema with the authoritative Blueprint Step-10 Workforce Manifest 2.0 schema.
- Added the exact Blueprint legacy 1.1 schema for bounded compatibility evidence.
- Added `WorkforceManifestNormalizer` using the Blueprint autonomy floor mapping.
- Rebuilt semantic validation around the 2.0 extension-owned contract.
- Added per-contributor quarantine instead of global discovery failure.
- Added manifest validation health via container adapter and authenticated API.
- Added owner/version/schema/fingerprint provenance to the internal role compatibility view.
- Adapted v2 proactive schedule/Signal declarations to the existing central Workforce scheduling/event runtime without creating business mutation authority.

## Safety invariants

- Schema 2.0 is canonical.
- Schema 1.1 is legacy-normalised only.
- Schema 1.0 is rejected rather than guessed.
- Legacy named Autonomy never maps above the floor of its former band.
- Effective authority and Predictive readiness remain Titan Autonomy outputs.
- Invalid manifests cannot produce activatable roles.
- One invalid extension cannot poison other extension manifests.
- Central Workforce still bundles zero domain roles/Action Workers.

## Deferred

Pass 4 owns install/upgrade/disable/uninstall lifecycle semantics, definition pinning for instantiated members/tasks, missing-definition state and breaking-change/deprecation handling.
