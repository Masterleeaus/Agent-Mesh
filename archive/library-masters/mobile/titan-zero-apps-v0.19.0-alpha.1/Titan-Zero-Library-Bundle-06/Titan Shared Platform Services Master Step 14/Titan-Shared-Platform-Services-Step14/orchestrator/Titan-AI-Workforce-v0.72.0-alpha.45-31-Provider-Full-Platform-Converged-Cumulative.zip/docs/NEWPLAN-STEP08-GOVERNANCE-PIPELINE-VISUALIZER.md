# New Roadmap Step 8 — Governance Pipeline Visualizer

Version: 0.59.0-alpha.32
Plan: `9876f30b-d86c-496d-b5b9-82227970aa5b`
Step: `step-08`

## Scope

Adds a company-scoped, read-only explainability surface for the canonical 12-stage Titan control-plane lifecycle:

Signal → Prime → AI Core → Agent Runtime → Model Council → Risk → Assurance → Governance → Autonomy → Command Bus → Rewind → Wisdom.

Every stage exposes its current state, timestamp, provider, decision summary, evidence references, reason, duration, failure and degradation state. The pipeline is projected from existing Workforce task, journey, evidence, execution-attempt and verified-outcome records; it does not create a second governance state machine.

## Operator workflow

- Open **Governance Pipeline** from AI Workforce navigation.
- Select a recent Work Item or open the pipeline directly from Work Item detail.
- Read the full lifecycle left-to-right.
- Drill into each stage for provider availability, recorded decision, evidence, timing and failure/degradation reason.
- Missing authoritative evidence remains **Pending** rather than being inferred as approved.
- Conditional stages such as Model Council and Rewind can explicitly show **Not required**.

## Authority boundary

The visualizer is evidence-only. It does not grant execution authority, infer approval from provider availability, bypass a failed gate, or convert missing evidence into permission. `authority_inherited=false` and `execution_authority_granted=false` are explicit on the overall projection and every stage.
