<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if (! $condition) $failures[] = $message;
};

$decisionPath = $root.'/System/Support/WorkforceAutonomyDecision.php';
$servicePath = $root.'/System/Services/WorkforceAutonomyService.php';
$schemaPath = $root.'/schemas/autonomy-decision.schema.json';
$governancePath = $root.'/System/Services/WorkforceGovernanceBridge.php';
$executionPath = $root.'/System/Services/WorkforceExecutionService.php';
$memberLifecyclePath = $root.'/System/Services/WorkforceMemberLifecycleService.php';
$maturityPath = $root.'/System/Services/WorkforceMaturityService.php';
$continuityPath = $root.'/System/Services/ManagerContinuityService.php';
$providerPath = $root.'/System/TitanAIWorkforceServiceProvider.php';
$catalogPath = $root.'/System/Support/WorkforceCapabilityCatalog.php';
$docsPath = $root.'/docs/PASS11-CONTINUOUS-TITAN-AUTONOMY.md';

foreach ([$decisionPath,$servicePath,$schemaPath,$docsPath] as $path) {
    $assert(is_file($path), 'missing Pass 11 file: '.basename($path));
}

if (is_file($decisionPath)) {
    require_once $decisionPath;
    $class = 'App\\Extensions\\TitanAIWorkforce\\System\\Support\\WorkforceAutonomyDecision';
    $key = [
        'company_id' => 7,
        'agent_id' => 'workforce-member:11',
        'capability' => 'crm.invoice.issue',
        'capability_variant' => 'standard',
        'vertical' => 'field_services',
        'workflow' => 'completed_job_invoice',
        'context' => 'ctx:abc',
    ];
    $valid = [
        'schema_version' => '2.0',
        'decision_id' => 'decision-1',
        'autonomy_key' => $key,
        'desired_score' => 94,
        'desired_band' => 'Predictive',
        'earned_score' => 81.6,
        'earned_band' => 'Trusted Auto',
        'effective_score' => 67,
        'effective_band' => 'Auto',
        'predictive_readiness_score' => 74.2,
        'predictive_readiness_band' => 'Trusted Auto',
        'allowed' => true,
        'lifecycle' => 'ACTIVE',
        'temporary_constraints' => [],
        'approval_requirements' => [],
        'restrictions' => [],
        'reason_codes' => ['ELIGIBLE'],
        'evidence_refs' => [],
        'policy_version' => 'autonomy-v2',
        'trace_id' => 'trace-1',
        'evaluated_at' => '2026-08-20T18:35:00+10:00',
    ];
    try {
        $checked = $class::validate($valid, $key);
        $assert(($checked['effective_score'] ?? null) === 67.0, 'valid decision must preserve continuous effective score');
    } catch (Throwable $e) {
        $assert(false, 'valid Autonomy Decision v2 must validate: '.$e->getMessage());
    }

    $mismatch = $valid;
    $mismatch['autonomy_key']['capability'] = 'crm.customer.delete';
    try {
        $class::validate($mismatch, $key);
        $assert(false, 'decision for a different capability must be rejected');
    } catch (Throwable) {}

    $inflated = $valid;
    $inflated['earned_score'] = 40;
    $inflated['earned_band'] = 'Semi-Auto';
    try {
        $class::validate($inflated, $key);
        $assert(false, 'effective authority above earned authority must be rejected');
    } catch (Throwable) {}

    $offline = $class::applyLocalPolicy($valid, 51, 'Auto', 'OFFLINE_EXECUTE', true, false, 50);
    $assert(($offline['allowed'] ?? true) === false, 'offline cap below capability minimum must block execution');
    $assert(($offline['local_effective_score'] ?? 999) <= 50, 'offline cap must only reduce authority');

    $predictive = $valid;
    $predictive['effective_score'] = 90;
    $predictive['effective_band'] = 'Predictive';
    $predictive['earned_score'] = 94;
    $predictive['earned_band'] = 'Predictive';
    $predictive['predictive_readiness_score'] = 80;
    $predictive['predictive_readiness_band'] = 'Trusted Auto';
    $predictivePolicy = $class::applyLocalPolicy($predictive, 86, 'Predictive', 'ONLINE_EXECUTE', false, true, null);
    $assert(($predictivePolicy['allowed'] ?? true) === false, 'Predictive execution must require Predictive readiness as well as capability authority');
}

$service = @file_get_contents($servicePath) ?: '';
foreach (['titan.autonomy','autonomy_key','effective_score','predictive_readiness_score','findOwnedCapability','model_provider_fingerprint','MODEL_PROVIDER_CHANGED','offline_authority_cap_score'] as $needle) {
    $assert(str_contains($service, $needle), 'continuous Autonomy service missing '.$needle);
}
$assert(! str_contains($service, 'maturity_level +'), 'maturity must never be added to authority');
$assert(! str_contains($service, 'Trusted Auto' . "' => true"), 'there must be no global Trusted Auto grant');

$governance = @file_get_contents($governancePath) ?: '';
$assert(str_contains($governance, 'WorkforceAutonomyService'), 'governance bridge must delegate Autonomy to the continuous authority service');
$assert(! str_contains($governance, "'effective_autonomy' => 'Suggest'"), 'legacy named-level fallback must be removed');

$execution = @file_get_contents($executionPath) ?: '';
$assert(str_contains($execution, "['autonomy']['allowed']"), 'execution must consume the capability-specific Autonomy decision');
$assert(str_contains($execution, 'effective_score'), 'execution evidence must retain continuous authority score');

$memberLifecycle = @file_get_contents($memberLifecyclePath) ?: '';
$assert(str_contains($memberLifecycle, "'effective_authority' => null"), 'member lifecycle must not persist/mint effective authority');
$assert(str_contains($memberLifecycle, "'self_promotion' => false"), 'staff activation must keep Autonomy self-promotion disabled');

$maturity = @file_get_contents($maturityPath) ?: '';
$assert(str_contains($maturity, "'autonomy_changed' => false"), 'maturity recommendations must not alter Autonomy');
$continuity = @file_get_contents($continuityPath) ?: '';
$assert(str_contains($continuity, "'authority_inherited' => false"), 'deputy coverage must not inherit Autonomy authority');

$provider = @file_get_contents($providerPath) ?: '';
$assert(str_contains($provider, "'titan.workforce.autonomy'"), 'stable continuous Autonomy adapter missing');
$catalog = @file_get_contents($catalogPath) ?: '';
$assert(str_contains($catalog, 'workforce.autonomy.read'), 'capability catalogue missing continuous Autonomy read contract');

$manifest = json_decode((string) file_get_contents($root.'/extension.manifest.json'), true, flags: JSON_THROW_ON_ERROR);
$assert(in_array('titan-workforce.continuous-autonomy', $manifest['capabilities'] ?? [], true), 'sidecar missing continuous-autonomy capability');

$schema = json_decode((string) @file_get_contents($schemaPath), true);
$assert(($schema['properties']['schema_version']['const'] ?? null) === '2.0', 'shipped Autonomy decision schema must be v2.0');
$assert(in_array('effective_score', $schema['required'] ?? [], true), 'Autonomy decision schema must require effective_score');
$assert(in_array('predictive_readiness_score', $schema['required'] ?? [], true), 'Autonomy decision schema must require Predictive readiness score');

$docs = @file_get_contents($docsPath) ?: '';
foreach (['0–100','Predictive','offline','model/provider','no global Trusted Auto','maturity','deputy'] as $needle) {
    $assert(str_contains($docs, $needle), 'Pass 11 docs missing '.$needle);
}

if ($failures !== []) {
    foreach ($failures as $failure) fwrite(STDERR, "FAIL: {$failure}\n");
    exit(1);
}

echo "PASS: Titan AI Workforce continuous Titan Autonomy contract\n";
