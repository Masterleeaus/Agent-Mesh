<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTaskStatus;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceExecutionReceipt;
use Throwable;

final class WorkforceExecutionService
{
    public function __construct(
        private readonly WorkforceGovernanceBridge $governance,
        private readonly WorkforceTaskService $tasks,
        private readonly WorkforceOutcomeFeedbackService $outcomes,
        private readonly WorkforceExecutionIntentService $intents,
        private readonly WorkforcePostActionVerificationService $verification,
        private readonly WorkforceExecutionRecoveryService $recovery,
        private readonly TitanZeroAuthorityGuard $titanZeroAuthorityGuard,
    ) {}

    public function execute(WorkforceTask $task, WorkforceMember $worker, array $command): WorkforceTask
    {
        $this->titanZeroAuthorityGuard->assertStandardGovernancePath($task, $worker, $command);
        $decision = $this->governance->evaluate($task, $worker);
        $interaction = $this->governance->prepareInteraction($task, $worker, $decision);
        $preExecution = array_merge($decision, ['interaction' => $interaction]);

        $task->forceFill([
            'risk_snapshot' => $decision['risk'],
            'assurance_snapshot' => $decision['assurance'],
            'autonomy_snapshot' => $decision['autonomy'],
            'governance' => array_merge($task->governance ?? [], ['pre_execution' => $preExecution]),
        ])->save();

        if (($decision['governance_complete'] ?? false) !== true) {
            return $this->tasks->transition($task, WorkforceTaskStatus::Blocked, $worker, 'execution.governance_unavailable', 'Risk, Assurance, required Model Council and Autonomy must all provide authoritative pre-execution decisions.', ['governance' => $decision]);
        }
        if (($interaction['required'] ?? false) === true && (($interaction['available'] ?? false) !== true || ($interaction['prepared'] ?? false) !== true)) {
            return $this->tasks->transition($task, WorkforceTaskStatus::Blocked, $worker, 'execution.interaction_blocked', $interaction['reason'] ?? 'Required Interaction workflow is unavailable or not ready.', ['interaction' => $interaction]);
        }
        if (($decision['missing_evidence'] ?? []) !== []) {
            return $this->tasks->transition($task, WorkforceTaskStatus::AwaitingData, $worker, 'execution.evidence_collection_required', 'Required evidence must be collected through the owning extension Interaction workflow before execution.', [
                'missing_evidence' => $decision['missing_evidence'], 'required_evidence' => $decision['required_evidence'] ?? [], 'interaction' => $interaction, 'assurance' => $decision['assurance'] ?? [],
            ]);
        }
        if (($decision['policy']['allowed'] ?? false) !== true) {
            return $this->tasks->transition($task, WorkforceTaskStatus::Blocked, $worker, 'execution.governance_policy_denied', 'Titan Risk/Assurance/Model Council policy did not authorize execution.', [
                'risk' => $decision['risk'] ?? [], 'assurance' => $decision['assurance'] ?? [], 'model_council' => $decision['model_council'] ?? [], 'policy' => $decision['policy'] ?? [],
            ]);
        }
        if (($decision['autonomy']['allowed'] ?? false) !== true) {
            return $this->tasks->transition($task, WorkforceTaskStatus::Blocked, $worker, 'execution.blocked', 'Autonomy did not authorize execution.', [
                'governance' => $decision, 'effective_score' => $decision['autonomy']['effective_score'] ?? null, 'effective_band' => $decision['autonomy']['effective_band'] ?? null,
                'decision_id' => $decision['autonomy']['decision_id'] ?? null, 'reason_codes' => $decision['autonomy']['reason_codes'] ?? [],
            ]);
        }

        try {
            $locked = $this->intents->lock($task->refresh(), $worker, $command);
        } catch (Throwable $e) {
            return $this->tasks->transition($task->refresh(), WorkforceTaskStatus::Blocked, $worker, 'execution.intent_rejected', $e->getMessage());
        }
        $attempt = $locked['attempt'];
        $this->tasks->record($task->refresh(), $worker, 'execution.intent_locked', $task->status->value, $task->status->value, null, [
            'attempt_uuid' => $attempt->attempt_uuid,
            'intent_id' => $attempt->intent_id,
            'intent_sha256' => $attempt->intent_sha256,
            'state_fingerprint' => $attempt->state_fingerprint,
            'idempotency_key' => $attempt->idempotency_key,
            'replayed' => $locked['replayed'],
        ]);

        $stateRevalidation = $this->intents->stateRevalidation($attempt, $task->refresh(), $worker);
        if (($stateRevalidation['matches_expected'] ?? false) !== true) {
            return $this->tasks->transition($task->refresh(), WorkforceTaskStatus::Blocked, $worker, 'execution.state_changed', 'Authoritative domain state changed before execution; regenerate/review intent before retry.', [
                'attempt_uuid' => $attempt->attempt_uuid,
                'stateRevalidation' => $stateRevalidation,
            ]);
        }

        $receipt = is_array($attempt->receipt) ? $attempt->receipt : null;
        $commandResult = null;
        $recovered = false;

        if ($receipt === null) {
            $task = $this->tasks->transition($task->refresh(), WorkforceTaskStatus::Executing, $worker, 'execution.started', null, [
                'attempt_uuid' => $attempt->attempt_uuid,
                'intent_id' => $attempt->intent_id,
                'idempotency_key' => $attempt->idempotency_key,
            ]);
            $attempt->forceFill(['status' => 'DISPATCHING', 'dispatched_at' => now()])->save();
            $commandResult = $this->governance->command($task, $worker, $command, [
                'intent_id' => $attempt->intent_id,
                'intent_sha256' => $attempt->intent_sha256,
                'state_fingerprint' => $attempt->state_fingerprint,
                'idempotency_key' => $attempt->idempotency_key,
                'expected_state' => $attempt->expected_state,
            ]);

            if (($commandResult['executed'] ?? false) !== true) {
                if (($commandResult['uncertain'] ?? false) === true) {
                    $reconcile = $this->recovery->reconcileReceipt($attempt->refresh(), $task->refresh(), $worker);
                    if (($reconcile['recovered'] ?? false) === true && is_array($reconcile['receipt'] ?? null)) {
                        $receipt = $reconcile['receipt'];
                        $recovered = true;
                        $this->tasks->record($task->refresh(), $worker, 'execution.recovered', $task->status->value, $task->status->value, null, ['receipt_ref' => $reconcile['receipt_ref'] ?? null]);
                    } else {
                        $task->forceFill(['result' => $commandResult])->save();
                        return $this->tasks->transition($task->refresh(), WorkforceTaskStatus::Recovery, $worker, 'execution.uncertain', 'Command Bus execution outcome is uncertain; reconcile receipt before any retry.', ['attempt_uuid' => $attempt->attempt_uuid, 'recovery' => $reconcile]);
                    }
                } else {
                    $attempt->refresh()->forceFill(['status' => 'COMMAND_BLOCKED', 'recovery' => ['reason_code' => 'COMMAND_BLOCKED', 'command_result' => $commandResult]])->save();
                    $task->forceFill(['result' => $commandResult])->save();
                    return $this->tasks->transition($task->refresh(), WorkforceTaskStatus::Blocked, $worker, 'execution.command_blocked', $commandResult['reason'] ?? 'Command Bus rejected execution.', ['receipt' => $commandResult['receipt'] ?? null]);
                }
            } else {
                $receipt = $commandResult['receipt'] ?? null;
            }
        }

        if ($receipt === null || $receipt === '') {
            $reconcile = $this->recovery->reconcileReceipt($attempt->refresh(), $task->refresh(), $worker);
            if (($reconcile['recovered'] ?? false) === true && is_array($reconcile['receipt'] ?? null)) {
                $receipt = $reconcile['receipt'];
                $recovered = true;
                $this->tasks->record($task->refresh(), $worker, 'execution.recovered', $task->status->value, $task->status->value, null, ['receipt_ref' => $reconcile['receipt_ref'] ?? null]);
            } else {
                $task->forceFill(['result' => $commandResult ?? ['executed' => true, 'receipt' => null]])->save();
                return $this->tasks->transition($task->refresh(), WorkforceTaskStatus::Recovery, $worker, 'execution.receipt_missing', 'Command Bus execution has no authoritative receipt; reconciliation is required before completion or retry.', ['attempt_uuid' => $attempt->attempt_uuid, 'recovery' => $reconcile]);
            }
        }

        try {
            $receipt = WorkforceExecutionReceipt::validate($receipt, [
                'company_id' => (int) $task->company_id,
                'task_id' => (string) $task->task_uuid,
                'capability' => (string) $task->capability,
                'intent_id' => (string) $attempt->intent_id,
                'intent_sha256' => (string) $attempt->intent_sha256,
                'idempotency_key' => (string) $attempt->idempotency_key,
            ]);
        } catch (Throwable $e) {
            $invalidReceipt = is_array($receipt) ? $receipt : ['raw' => $receipt];
            $attempt->refresh()->forceFill([
                'receipt' => $invalidReceipt,
                'receipt_sha256' => hash('sha256', json_encode($invalidReceipt, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)),
                'status' => 'RECOVERY_REQUIRED',
                'recovery' => ['reason_code' => 'RECEIPT_INVALID', 'error' => $e->getMessage()],
            ])->save();
            return $this->tasks->transition($task->refresh(), WorkforceTaskStatus::Recovery, $worker, 'execution.receipt_invalid', 'Command Bus returned a receipt that does not match the locked execution intent.', ['attempt_uuid' => $attempt->attempt_uuid, 'error' => $e->getMessage()]);
        }
        $this->recovery->storeReceipt($attempt->refresh(), $receipt, $recovered ? 'RECONCILED' : 'RECEIPT_VALIDATED');

        $verification = $this->verification->verifyReceipt($attempt->refresh(), $task->refresh(), $worker, $receipt, $command);
        if (($verification['verified'] ?? false) !== true) {
            return $this->tasks->transition($task->refresh(), WorkforceTaskStatus::Recovery, $worker, 'execution.verification_failed', 'Command Bus receipt exists but the authoritative post-action state has not been verified.', [
                'attempt_uuid' => $attempt->attempt_uuid,
                'receipt_ref' => $receipt['receipt_id'] ?? null,
                'verification' => $verification,
                'compensation_available' => in_array((string) ($locked['capability']['reversibility'] ?? 'irreversible'), ['reversible','compensatable'], true),
            ]);
        }

        $feedbackInput = is_array($commandResult) ? $commandResult : [];
        $feedbackInput['executed'] = true;
        $feedbackInput['receipt'] = $receipt;
        $feedbackInput['verification'] = $verification;
        $feedbackInput['attempt_uuid'] = $attempt->attempt_uuid;
        $feedbackInput['intent_id'] = $attempt->intent_id;
        $feedbackInput['intent_sha256'] = $attempt->intent_sha256;
        $feedbackInput['idempotency_key'] = $attempt->idempotency_key;
        $feedback = $this->outcomes->record($task->refresh(), $worker, $feedbackInput);
        $attempt->refresh()->forceFill(['status' => 'COMPLETED'])->save();
        $task->forceFill(['result' => array_merge($feedbackInput, ['outcome_feedback' => $feedback])])->save();

        return $this->tasks->transition($task->refresh(), WorkforceTaskStatus::Completed, $worker, 'execution.completed', null, [
            'attempt_uuid' => $attempt->attempt_uuid,
            'receipt' => $receipt,
            'receipt_ref' => $feedback['receipt_ref'] ?? ($receipt['receipt_id'] ?? null),
            'verification_ref' => $verification['domain_state_ref'] ?? null,
            'rewind_ref' => $feedback['rewind_ref'] ?? null,
            'outcome_ref' => $feedback['outcome_ref'] ?? null,
        ]);
    }
}
