# New Roadmap Step 03 — Notifications & Alert Routing

Version: `0.54.0-alpha.27`

Turns authoritative Workforce Attention conditions into governed, company-scoped in-app notifications. Routing supports owner/admin, responsible manager and specific team audiences with a company-configurable 1–5 severity threshold. Stable dedupe keys collapse repeated occurrences into one alert with occurrence counts; operators can acknowledge alerts without resolving or authorizing the underlying work.

## Authority invariant

Notifications are informational routing only. Neither routing, acknowledgement, recipient selection nor severity configuration grants capability, transfers responsibility, approves work, or changes Risk, Assurance, Governance or Autonomy decisions.
