<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$ok = static function (bool $condition, string $message) use (&$failures): void {
    if (! $condition) $failures[] = $message;
};

foreach ([
    'System/Support/WorkforceEcosystemCapabilityRegistry.php',
    'resources/workforce/ecosystem-capability-registry.json',
    'resources/workforce/ecosystem-capability-registry.schema.json',
    'resources/workforce/ecosystem-provider-aliases.json',
    'tools/build_ecosystem_capability_registry.py',
    'docs/PASS11-FULL-ECOSYSTEM-CAPABILITY-REGISTRY.md',
] as $path) {
    $ok(is_file($root . '/' . $path), "Step 11 artifact missing: {$path}");
}

$catalog = is_file($root . '/resources/workforce/ecosystem-capability-registry.json')
    ? json_decode((string) file_get_contents($root . '/resources/workforce/ecosystem-capability-registry.json'), true)
    : [];
$providers = is_array($catalog['providers'] ?? null) ? $catalog['providers'] : [];
$ok(($catalog['schema_version'] ?? null) === '1.0', 'ecosystem capability registry schema_version must be 1.0');
$ok(($catalog['organisation_owner'] ?? null) === 'titan-ai-workforce', 'ecosystem registry must preserve Workforce organisation ownership');
$ok(($catalog['tenant_key'] ?? null) === 'company_id', 'ecosystem registry tenant key must be company_id');
$ok(count($providers) === 31, 'ecosystem registry must contain exactly 31 canonical supplied providers');

$expected = [
    'crm','titan-ai','titan-ai-core','titan-ai-vision','titan-assets','titan-assurance','titan-autonomy','titan-command-bus',
    'titan-connect','titan-field','titan-financial-engine','titan-forge','titan-governance','titan-interaction-engine',
    'titan-knowledge-authority','titan-ledger','titan-locker','titan-maps-intelligence','titan-mcp','titan-model-council',
    'titan-nexus','titan-payroll','titan-people','titan-prime','titan-rewind','titan-risk-engine','titan-shield','titan-signal-engine','titan-time-attendance','titan-trust','titan-wisdom',
];
$providerKeys = [];
$capabilityIds = [];
foreach ($providers as $provider) {
    $key = (string) ($provider['extension']['key'] ?? '');
    $providerKeys[] = $key;
    $ok((string) ($provider['extension']['version'] ?? '') !== '', "provider {$key} version missing");
    $ok((string) ($provider['extension']['provider_class'] ?? '') !== '', "provider {$key} provider_class missing");
    $ok(is_string($provider['provenance']['archive_sha256'] ?? null) && strlen((string) $provider['provenance']['archive_sha256']) === 64, "provider {$key} archive provenance missing");
    $ok(($provider['ownership']['role_definitions_owned_by_provider'] ?? null) === false, "provider {$key} must not own Workforce roles");
    $ok(($provider['ownership']['provider_owns_execution_surfaces'] ?? null) === true, "provider {$key} must own its execution surfaces");
    $ok(($provider['runtime']['availability_requires_installed_provider'] ?? null) === true, "provider {$key} must be runtime-gated by installation");
    foreach (['capabilities','tools','commands','signals','data_sources','workflows','role_bindings'] as $section) {
        $ok(is_array($provider[$section] ?? null), "provider {$key} {$section} must be an array");
    }
    foreach ((array) ($provider['capabilities'] ?? []) as $capability) {
        $id = (string) ($capability['id'] ?? $capability['name'] ?? '');
        $ok($id !== '', "provider {$key} capability id missing");
        $ok(in_array((string) ($capability['authority'] ?? ''), ['authoritative','compatibility','informational'], true), "provider {$key} capability {$id} authority classification invalid");
        $capabilityIds[$key . '|' . $id] = true;
    }
    foreach ((array) ($provider['role_bindings'] ?? []) as $binding) {
        $ok(($binding['authority_inherited'] ?? null) === false, "provider {$key} role binding must never inherit authority");
        $ok(str_starts_with((string) ($binding['role_definition_id'] ?? ''), 'titan.'), "provider {$key} role binding must target canonical Workforce role identity");
    }
}
sort($providerKeys); sort($expected);
$ok($providerKeys === $expected, 'ecosystem registry provider keys must exactly match the 31 supplied canonical extensions');
$ok(count($capabilityIds) >= 700, 'ecosystem registry must import at least 700 provider-qualified real capability surfaces');

$byKey = [];
foreach ($providers as $provider) $byKey[(string) $provider['extension']['key']] = $provider;
$minimumCapabilities = [
    'crm' => 253,
    'titan-field' => 26,
    'titan-assets' => 45,
    'titan-locker' => 12,
    'titan-ledger' => 105,
    'titan-time-attendance' => 14,
    'titan-connect' => 8,
    'titan-financial-engine' => 17,
    'titan-maps-intelligence' => 44,
    'titan-ai-vision' => 32,
    'titan-mcp' => 36,
];
foreach ($minimumCapabilities as $key => $minimum) {
    $ok(count((array) ($byKey[$key]['capabilities'] ?? [])) >= $minimum, "provider {$key} must import at least {$minimum} real capabilities");
}
$ok(count((array) ($byKey['titan-field']['tools'] ?? [])) >= 14, 'Titan Field must import its 14 declared Workforce tools');
$ok(count((array) ($byKey['titan-time-attendance']['tools'] ?? [])) >= 18, 'Time & Attendance must import its 18 declared Workforce tools');
$ok(count((array) ($byKey['titan-time-attendance']['signals'] ?? [])) >= 16, 'Time & Attendance must import its 16 declared signals');
$ok(count((array) ($byKey['titan-time-attendance']['workflows'] ?? [])) >= 4, 'Time & Attendance must import its 4 declared workflows');
$ok(count((array) ($byKey['titan-connect']['commands'] ?? [])) >= 4, 'Titan Connect must expose its concrete messaging command gateway methods');
$ok(count((array) ($byKey['titan-financial-engine']['data_sources'] ?? [])) >= 17, 'Financial Engine must expose all 17 deterministic calculation engines as governed read/calculation surfaces');

$aliases = is_file($root . '/resources/workforce/ecosystem-provider-aliases.json')
    ? json_decode((string) file_get_contents($root . '/resources/workforce/ecosystem-provider-aliases.json'), true)
    : [];
$aliasMap = is_array($aliases['aliases'] ?? null) ? $aliases['aliases'] : [];
$ok(($aliasMap['titan-signal'] ?? null) === 'titan-signal-engine', 'titan-signal alias must resolve to titan-signal-engine');
$ok(($aliasMap['titan-risk'] ?? null) === 'titan-risk-engine', 'titan-risk alias must resolve to titan-risk-engine');
$ok(($aliasMap['titan-ai-assurance'] ?? null) === 'titan-assurance', 'titan-ai-assurance alias must resolve to titan-assurance');

$registry = is_file($root . '/System/Support/WorkforceEcosystemCapabilityRegistry.php')
    ? (string) file_get_contents($root . '/System/Support/WorkforceEcosystemCapabilityRegistry.php') : '';
foreach (['all', 'installedContributions', 'canonicalProviderKey', 'capabilityOwners', 'provider', 'availability_requires_installed_provider'] as $needle) {
    $ok(str_contains($registry, $needle), "ecosystem registry implementation missing {$needle}");
}
$ok(str_contains($registry, 'class_exists'), 'runtime ecosystem activation must verify the provider class is actually installed');

$bindingRegistry = (string) file_get_contents($root . '/System/Support/WorkforceCapabilityBindingRegistry.php');
$ok(str_contains($bindingRegistry, 'WorkforceEcosystemCapabilityRegistry'), 'capability binding registry must consume the full ecosystem registry');
$ok(str_contains($bindingRegistry, 'installedContributions'), 'only installed ecosystem providers may enter effective runtime access');

$serviceProvider = (string) file_get_contents($root . '/System/TitanAIWorkforceServiceProvider.php');
$ok(str_contains($serviceProvider, 'WorkforceEcosystemCapabilityRegistry::class'), 'service provider must register ecosystem registry');
$ok(str_contains($serviceProvider, "'titan.workforce.ecosystem-capabilities'"), 'public ecosystem capability adapter missing');

$manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, flags: JSON_THROW_ON_ERROR);
$ok(in_array('titan-workforce.ecosystem-capability-registry-v1', $manifest['capabilities'] ?? [], true), 'extension manifest missing ecosystem capability registry capability');
$ok(($manifest['workforce']['ecosystem_provider_count'] ?? null) === 31, 'sidecar must declare 31 normalised ecosystem providers');

if ($failures !== []) {
    foreach ($failures as $failure) fwrite(STDERR, "FAIL: {$failure}\n");
    exit(1);
}

echo "PASS: Titan AI Workforce full ecosystem capability registry contract\n";
