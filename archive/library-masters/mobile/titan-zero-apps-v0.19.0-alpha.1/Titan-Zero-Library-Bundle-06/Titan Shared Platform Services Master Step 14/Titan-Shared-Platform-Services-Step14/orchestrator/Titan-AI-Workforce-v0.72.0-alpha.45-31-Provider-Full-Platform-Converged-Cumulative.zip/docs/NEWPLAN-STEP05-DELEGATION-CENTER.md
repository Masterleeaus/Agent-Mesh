# New Plan Step 05 — Delegation Center

Titan AI Workforce now exposes a company-scoped Delegation Center covering delegator, delegate, responsibility, work scope, start/end, Active/Expired/Revoked lifecycle, related tasks, reason, audit history and the explicit authority boundary.

Governed Action Worker delegation persists a WorkforceDelegation record. Delegation scope is capped to the source task capability and records `delegator_may_expand_authority=false`, `authority_inherited=false`, `execution_authority_granted=false`, and `requires_fresh_execution_authorization=true`.

Delegation is organisational work routing only. It does not grant capability or bypass capability availability, Risk, Assurance, Governance, Titan Autonomy, or Command Bus controls.
