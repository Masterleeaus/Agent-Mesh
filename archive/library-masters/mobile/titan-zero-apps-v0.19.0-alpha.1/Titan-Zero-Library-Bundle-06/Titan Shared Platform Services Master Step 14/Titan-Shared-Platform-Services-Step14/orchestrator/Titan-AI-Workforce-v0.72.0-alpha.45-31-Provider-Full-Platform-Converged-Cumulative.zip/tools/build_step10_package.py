#!/usr/bin/env python3
"""Build a flat Titan Installer 1.7.8 ZIP from this extension tree."""
from __future__ import annotations
import argparse, sys, zipfile, shutil
sys.dont_write_bytecode=True
from pathlib import Path, PurePosixPath
from build_installer_manifest import build
from verify_zip import verify

JUNK_DIRS={'.git','__pycache__','node_modules','vendor'}
JUNK_FILES={'.DS_Store'}

def package(source:Path, output:Path)->None:
    source=source.resolve(); output=output.resolve()
    for cache in source.rglob('__pycache__'):
        if cache.is_dir(): shutil.rmtree(cache)
    for pyc in source.rglob('*.pyc'):
        pyc.unlink(missing_ok=True)
    build(source)
    files=[]
    for p in sorted(source.rglob('*'), key=lambda p:p.relative_to(source).as_posix()):
        rel=p.relative_to(source)
        if p.is_symlink(): raise ValueError(f'symlink not allowed: {rel.as_posix()}')
        if not p.is_file(): continue
        if p.resolve()==output: continue
        if any(part in JUNK_DIRS for part in rel.parts) or rel.name in JUNK_FILES or rel.suffix=='.pyc': continue
        name=rel.as_posix()
        pure=PurePosixPath(name)
        if '\\' in name or pure.is_absolute() or '..' in pure.parts: raise ValueError(f'unsafe path: {name}')
        files.append((p,name))
    output.parent.mkdir(parents=True,exist_ok=True)
    if output.exists(): output.unlink()
    with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as zf:
        for p,name in files: zf.write(p,name)
    errors=verify(str(output))
    if errors: raise ValueError('; '.join(errors))

def main()->int:
    ap=argparse.ArgumentParser(); ap.add_argument('extension_dir'); ap.add_argument('output_zip'); args=ap.parse_args()
    try: package(Path(args.extension_dir),Path(args.output_zip))
    except Exception as exc: print('ERROR:',exc,file=sys.stderr); return 1
    print(f'OK: flat Installer 1.7.8 package created: {Path(args.output_zip).resolve()}')
    return 0
if __name__=='__main__': raise SystemExit(main())
