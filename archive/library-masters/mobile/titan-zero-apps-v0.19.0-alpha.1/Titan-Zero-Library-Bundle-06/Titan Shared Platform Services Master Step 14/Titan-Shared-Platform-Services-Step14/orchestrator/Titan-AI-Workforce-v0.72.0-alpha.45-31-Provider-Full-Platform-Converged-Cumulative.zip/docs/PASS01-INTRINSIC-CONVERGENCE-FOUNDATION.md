# Pass 1 — Baseline Preservation & Ecosystem Map

Pass 1 freezes Titan AI Workforce v0.27.0-alpha.27 as the executable parent, preserves v0.5.0-alpha.5 as the intrinsic-team donor, and inventories the 28 canonical supplied extension identities.

This pass changes **documentation, package version/provenance and integrity metadata only**. No `System/`, migration, route, configuration, Blade or other runtime behavior file is changed.

## Locked evidence

- 15 intrinsic divisions, 111 intrinsic roles, 19 scheduled routines and 44 event routines in the v0.5 donor.
- 28 unique supplied extension identities after deterministic Knowledge Authority Pass4-H2 de-duplication.
- Compatibility ledger preserves known blockers rather than silently weakening contracts.
- Capability ownership rule: **Workforce owns roles; extensions own capabilities.**
- Signal routing rule: **signals describe business changes; Workforce assigns organisational responsibility.**
- Canonical Workforce tenant/company boundary: `company_id`.
- Restore/translate/replace/retire map preserves modern v0.27 governance/execution while identifying v0.5 organisational assets for future restoration.

## Identifiers

- CODEE plan: `4de3a29c-6bea-4d50-b6f9-380c29f6ba4d`
- Architecture plan: `4afc3d5e-78c4-4d7a-9a1f-b7526d5b7032`
- Run: `run-1a526598-4ced-4f3b-aaaf-cb1529c9707d`
- Step: `step-01`

See `docs/pass1/` for machine-readable evidence.
