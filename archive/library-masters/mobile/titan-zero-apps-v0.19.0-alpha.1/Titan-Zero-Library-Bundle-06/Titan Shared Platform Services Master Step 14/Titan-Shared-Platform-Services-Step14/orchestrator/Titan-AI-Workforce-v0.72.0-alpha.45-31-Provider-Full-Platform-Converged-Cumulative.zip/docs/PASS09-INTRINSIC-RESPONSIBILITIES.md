# Integrated Upgrade Pass 9 — Intrinsic Responsibilities

Pass 9 restores the v0.5 role accountability catalogue as canonical Workforce-owned responsibility definitions while keeping execution authority separate.

## Canonical rules

- Workforce owns the 114 intrinsic responsibility definitions and their 114 role assignments.
- All 111 intrinsic roles retain at least one required responsibility; Operations Manager retains its four historical responsibilities.
- Responsibilities use stable `titan.responsibility.*` IDs and remain definition-only: `is_executable=false`, `capability_authority=NONE`, and `authority_inherited=false`.
- Role definitions expose canonical `responsibility_ids` while retaining the historical human-readable `responsibilities` text for compatibility.
- Responsibility definitions inherit division, team, vertical applicability and recommended business maturity from the canonical role that owns the accountability.
- External extensions do not own or replace employee responsibilities. They continue to provide executable capabilities, tools, signals, data sources and workflow/runtime integration.
- Proactive scheduled/event routines remain separate and are not restored by Pass 9. Their convergence remains assigned to later roadmap passes.
- Pass 9 creates no employees, tasks, schedules or triggers and grants no execution authority.
