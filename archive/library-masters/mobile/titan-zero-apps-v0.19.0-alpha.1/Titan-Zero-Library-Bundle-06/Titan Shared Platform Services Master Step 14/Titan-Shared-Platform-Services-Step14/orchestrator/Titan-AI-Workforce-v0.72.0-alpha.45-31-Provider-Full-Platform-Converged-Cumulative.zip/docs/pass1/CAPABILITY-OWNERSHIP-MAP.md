# Pass 1 Capability Ownership Map

**Rule:** Workforce owns roles; extensions own capabilities.

| Provider | Category | Published capabilities | Status |
|---|---|---:|---|
| `crm` | business_domain | 260 | published |
| `titan-ai` | interaction_cognition | 11 | published |
| `titan-ai-core` | interaction_cognition | 8 | published |
| `titan-ai-vision` | evidence_learning | 32 | published |
| `titan-assets` | business_domain | 45 | published |
| `titan-assurance` | control_plane | 3 | published |
| `titan-autonomy` | control_plane | 9 | published |
| `titan-command-bus` | control_plane | 3 | published |
| `titan-connect` | business_domain | 0 | not_detected |
| `titan-field` | business_domain | 53 | published |
| `titan-financial-engine` | business_domain | 0 | governed_public_capability_gap |
| `titan-forge` | platform_ops | 17 | published |
| `titan-governance` | control_plane | 27 | published |
| `titan-interaction-engine` | interaction_cognition | 23 | published |
| `titan-knowledge-authority` | evidence_learning | 1 | published |
| `titan-ledger` | business_domain | 105 | published |
| `titan-locker` | business_domain | 28 | published |
| `titan-maps-intelligence` | business_domain | 44 | published |
| `titan-mcp` | platform_ops | 28 | published |
| `titan-model-council` | interaction_cognition | 28 | published |
| `titan-nexus` | platform_ops | 27 | published |
| `titan-prime` | interaction_cognition | 15 | published |
| `titan-rewind` | evidence_learning | 51 | published |
| `titan-risk-engine` | control_plane | 6 | published |
| `titan-shield` | control_plane | 9 | published |
| `titan-signal-engine` | control_plane | 15 | published |
| `titan-time-attendance` | business_domain | 23 | published |
| `titan-wisdom` | evidence_learning | 6 | published |

Unique detected capabilities: **876**
Exact capability-name overlaps: **1**

