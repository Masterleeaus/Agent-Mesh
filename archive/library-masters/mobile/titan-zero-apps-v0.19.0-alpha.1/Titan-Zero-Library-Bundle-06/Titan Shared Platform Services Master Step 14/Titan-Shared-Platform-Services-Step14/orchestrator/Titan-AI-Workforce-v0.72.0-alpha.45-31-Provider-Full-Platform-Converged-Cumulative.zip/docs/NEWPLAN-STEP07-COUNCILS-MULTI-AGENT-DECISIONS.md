# New Roadmap Step 7 — Councils & Multi-Agent Decisions

Version: 0.58.0-alpha.31
Plan: `9876f30b-d86c-496d-b5b9-82227970aa5b`
Step: `step-07`

## Scope

Turns Workforce Councils from a task-generation helper into a company-scoped operational deliberation system.

Built-in templates:

- Executive Operations
- Finance Review
- Risk & Compliance
- Quality
- Customer Recovery
- Major Incident
- Staffing
- Strategic Planning

Each council persists its chair and participants, current issue, evidence, proposals, dissent, recommendation, final decision, audit trail and follow-up Work Items. Convening a council creates a governed council Work Item so deliberation remains visible in the main Workforce work/journey surfaces.

## Decision flow

1. Convene a built-in council around a concrete issue.
2. Resolve the active chair and participants from company-scoped Workforce staff.
3. Record evidence, proposals and dissent with participant attribution.
4. Record a recommendation.
5. The chair may record the final council decision.
6. The chair may create separate follow-up Work Items.
7. Every follow-up Work Item is explicitly marked `requires_fresh_execution_authorization=true`.

## Authority boundary

Council participation and council decisions are organisational/governance evidence. They do not grant executable capability, do not inherit authority, and do not bypass capability availability, Risk, Assurance, Governance, Titan Autonomy or Command Bus execution controls.
