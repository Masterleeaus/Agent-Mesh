<?php

declare(strict_types=1);

function fail_control(string $message): never { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); }
function ok_control(bool $condition, string $message): void { if (! $condition) fail_control($message); }

$root = dirname(__DIR__, 2);

foreach ([
    '/System/Services/WorkforceControlRoomService.php',
    '/System/Services/WorkforcePerformanceService.php',
    '/System/Services/WorkforceStaffingProposalService.php',
    '/System/Models/WorkforceStaffingProposal.php',
    '/resources/views/workforce/control-room/index.blade.php',
    '/database/migrations/2026_08_15_000003_create_workforce_staffing_proposals.php',
    '/docs/CROSS-EXTENSION-ACCEPTANCE-MATRIX.md',
] as $path) {
    ok_control(is_file($root . $path), basename($path) . ' missing');
}

$control = (string) file_get_contents($root . '/System/Services/WorkforceControlRoomService.php');
foreach ([
    'WorkforceTrustHealthService',
    'WorkforceQueueHealthService',
    'WorkforcePerformanceService',
    'WorkforceStaffingProposalService',
    'WorkforceTaskHandoff',
    'WorkforceRelationship',
    "'organisation_graph'",
    "'queues'",
    "'trust_health'",
    "'handoffs'",
    "'approvals'",
    "'staffing'",
    "'performance'",
    "'outcome_refs'",
] as $needle) {
    ok_control(str_contains($control, $needle), 'control room missing ' . $needle);
}

$performance = (string) file_get_contents($root . '/System/Services/WorkforcePerformanceService.php');
foreach ([
    'manager_acceptance_rate',
    'downstream_acceptance_rate',
    'assurance_calibration',
    'policy_violations',
    'recent_serious_failure',
    'WorkforceMaturityService',
    "'maturity'",
    "'authority_changed'",
] as $needle) {
    ok_control(str_contains($performance, $needle), 'performance service missing ' . $needle);
}

$staffing = (string) file_get_contents($root . '/System/Services/WorkforceStaffingProposalService.php');
foreach ([
    'WorkforcePlanningService',
    "'auto_activate' => false",
    'approve',
    'reject',
    'APPROVED',
    'REJECTED',
    'RECOMMENDED',
] as $needle) {
    ok_control(str_contains($staffing, $needle), 'staffing proposal service missing ' . $needle);
}
ok_control(! str_contains($staffing, 'WorkforceMember::query()->create'), 'staffing approval must not create Workforce Members');

$controller = (string) file_get_contents($root . '/System/Http/Controllers/WorkforceController.php');
foreach ([
    'WorkforceControlRoomService',
    'WorkforceStaffingProposalService',
    'controlRoom',
    'approveStaffingProposal',
    'rejectStaffingProposal',
] as $needle) {
    ok_control(str_contains($controller, $needle), 'controller missing ' . $needle);
}

$provider = (string) file_get_contents($root . '/System/TitanAIWorkforceServiceProvider.php');
foreach ([
    "'titan.workforce.control-room'",
    "'titan.workforce.performance'",
    "'titan.workforce.staffing-proposals'",
    "\$router->get('control-room'",

] as $needle) {
    ok_control(str_contains($provider, $needle), 'provider missing ' . $needle);
}

$nav = (string) file_get_contents($root . '/System/Navigation/WorkforceNavigation.php');
ok_control(str_contains($nav, "'Control Room'"), 'navigation missing Control Room');

$view = (string) file_get_contents($root . '/resources/views/workforce/control-room/index.blade.php');
foreach (['Organisation','Trust & risk','Approvals','Handoffs','Staffing','Performance','Rewind'] as $needle) {
    ok_control(str_contains($view, $needle), 'Control Room view missing ' . $needle);
}

$manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, flags: JSON_THROW_ON_ERROR);
foreach ([
    'titan-workforce.control-room',
    'titan-workforce.performance-evidence',
    'titan-workforce.staffing-proposals',
] as $capability) {
    ok_control(in_array($capability, $manifest['capabilities'] ?? [], true), 'manifest missing ' . $capability);
}
ok_control(($manifest['version'] ?? null) === '0.72.0-alpha.45', 'manifest version must be 0.72.0-alpha.45');

$extension = json_decode((string) file_get_contents($root . '/extension.json'), true, flags: JSON_THROW_ON_ERROR);
ok_control(($extension['version'] ?? null) === '0.72.0-alpha.45', 'extension version must be 0.72.0-alpha.45');

$acceptance = (string) file_get_contents($root . '/docs/CROSS-EXTENSION-ACCEPTANCE-MATRIX.md');
foreach ([
    'NO direct AI database mutation',
    'NO self-approval',
    'NO global autonomy escalation',
    'NO completed mutation without an execution receipt',
    'NO important decision without a trace',
    'Customer request',
    'Titan Command Bus',
    'Titan Rewind',
    'Titan Wisdom',
] as $needle) {
    ok_control(str_contains($acceptance, $needle), 'acceptance matrix missing ' . $needle);
}

fwrite(STDOUT, "PASS: Control Room and final acceptance contract\n");
