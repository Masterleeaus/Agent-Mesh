# Titan AI Workforce v0.72.0-alpha.45

## New Roadmap Step 13 — Workforce Planning 2.0

Upgrades Workforce Planning into a company-scoped capacity planning surface covering overloaded teams, underused staff, responsibility and capability gaps, manager span, bottlenecks, upcoming workload, proposed roles, expected benefit and provider requirements. Staffing remains explicit and approval-gated: recommendations never auto-hire staff or grant authority.

## New Roadmap Step 12 — Workforce Performance & Coaching

Uses verified outcomes plus authoritative work-quality signals to surface strengths, weak responsibilities, revision pressure, failed handoffs, recurring escalations, execution latency and poor outcome conversion. Recommendations are advisory only: performance never auto-increases authority, autonomy, capability, staffing configuration or risk ceiling.

## New Roadmap Step 10 — Journey Timeline 2.0

Turns the append-only Workforce journey spine into a business-readable timeline. Operators see concise milestones first—who acted, what changed, and why—while event UUID/hash, trace/correlation IDs, rationale/evidence/decision/execution/outcome references and structured payloads remain collapsed inside per-event technical detail. The timeline is company-scoped, read-only, excludes private reasoning and never infers or grants execution authority.

## New Roadmap Step 9 — Execution & Evidence Explorer

Adds a company-scoped forensic explorer across Work Items, employees, execution intents, Risk, Assurance, Governance, Autonomy, Command Bus commands, execution attempts, receipts, evidence, state verification, Rewind recovery and final outcomes. The explorer is read-only and never grants execution authority.

## New Roadmap Step 7 — Councils & Multi-Agent Decisions

Adds a company-scoped Councils & Multi-Agent Decisions system with eight built-in templates: Executive Operations, Finance Review, Risk & Compliance, Quality, Customer Recovery, Major Incident, Staffing and Strategic Planning. Councils persist chair/participants plus issue, evidence, proposals, dissent, recommendation, final decision and follow-up Work Items. Council decisions remain organisational evidence only; follow-up work requires fresh execution authorization and cannot inherit capability or authority.


## New Roadmap Step 6 — Escalation & Deadlock Center

Adds a company-scoped Escalation & Deadlock Center that unifies open escalations and governed deadlock states. It visualises the escalation path Specialist → Manager → Division Manager → AI Business Manager → Titan Zero → Human, and exposes reason, age, evidence, immutable prior decisions, blocked downstream work and the required resolver. Retry with evidence, return to maker, escalate, human decision and resolve actions reuse governed task/chain-of-command services. Escalation changes who must decide; it never grants executable capability or bypasses Risk, Assurance, Governance or Autonomy.

## New Roadmap Step 5 — Delegation Center

Adds a company-scoped Delegation Center that makes delegator, delegate, responsibility, work scope, lifecycle, related tasks, reason, authority boundary and audit history visible. Governed Action Worker delegation now persists an explicit WorkforceDelegation record. Delegation never grants executable capability or authority; delegated work requires fresh capability, Risk, Assurance, Governance and Titan Autonomy authorization.

## UI Step 10 — Capability Health & Provider Inspector

Adds a company-scoped inspector across Providers, Roles, Employees, Capabilities, Tools, Commands, Signals, Data sources and Workflows. Provider state distinguishes installed/active/degraded/missing/quarantined; employee state distinguishes expected providers, live available providers, degraded capabilities, policy-disabled capabilities and canonical fallback eligibility. Availability and fallback eligibility never grant authority.


## v0.45.0-alpha.18 — UI Step 4: Team & Division Workspaces

Adds dedicated company-scoped operational homes for every canonical Workforce division and team. Each workspace resolves leadership, members, canonical responsibilities, live work queue and pressure, top-level objectives, blocked work, handoffs, capability-provider health, schedules, performance metrics and verified outcomes from existing authoritative Workforce records. Division/team health is a read-only projection and never inherits or grants execution authority. Organisation-map division/team names now drill directly into these workspaces, while every staff card continues into Employee 360.

## v0.45.0-alpha.18 — UI Step 3: Interactive Organisation Map

Replaces the simple Team listing with a company-scoped interactive organisation map across divisions, teams, managers, specialists and other visible Workforce members. The map layers canonical reporting, deputies/substitutes, delegation, escalation and cross-team coordination over live capability-provider health, workload and missing-manager signals. Staff nodes link directly to Employee 360 and support division, team, role, lifecycle, degraded, overloaded, missing-manager and provider-dependency filters. Organisational edges and provider availability never grant authority.

## v0.43.0-alpha.16 — UI Step 2: Employee 360° Profile

Adds a dedicated employee workspace with Overview, Responsibilities, Work, Capabilities, Tools, Schedule, Delegations, Escalations, Performance, Outcomes, Runtime and History tabs. The signature capability-reality table separates canonical binding (Can do), live availability (Currently available), and task-scoped Titan Autonomy decisions (Allowed/Authorized); unknown authority is never presented as permission.

## v0.42.0-alpha.15 — UI Step 1: Workforce Command Dashboard

The Overview is now the owner-facing operational command home. It surfaces live staff capability health, work-state pressure, provider health, manager queues, overdue proactive responsibilities, execution failure/recovery signals, outcome verification health, staffing recommendations, immutable critical events, and a deterministic **Needs attention now** queue. The dashboard is read-only, company-scoped through `company_id`, and never converts capability availability into execution authority.



## Integrated Upgrade Pass 14 — Role Capability Availability & Safe Degradation

Pass 14 makes provider capability state live for every intrinsic employee. Workforce now distinguishes `available`, `unavailable`, `degraded`, `blocked`, `missing_provider` and `policy_disabled`; task creation, workload reassignment and Autonomy re-check the live state rather than trusting cached member capability snapshots. Extension lifecycle events invalidate capability bindings immediately, role identity remains immutable when providers disappear, and neither the matrix nor degradation/fallback logic grants authority.

## Integrated Upgrade Pass 13 — Canonical Capability Binding Matrix

Pass 13 makes Workforce the definitive owner of role-to-provider composition across all 111 intrinsic roles plus the AI Business Manager and Titan Zero. The canonical matrix contains 113 role rows and 313 provider bindings, with 96 roles deliberately composed from multiple providers. Provider packages still own their capabilities, tools, commands, signals, data sources and workflows; the matrix only defines which intrinsic role may see which installed provider surfaces and grants no execution authority. Titan Zero remains coordination-only with zero domain provider bindings. Runtime bindings fail closed if a provider is absent or no longer publishes a matrix-pinned surface.


## Integrated Upgrade Pass 12 — Control-Plane Integration Registry

Pass 12 formalises the 12-stage Workforce decision/execution lifecycle: Signal observe, Titan Prime mission, Titan AI Core plan, Titan AI Runtime reason, Model Council deliberate, Risk assess, Assurance verify, Governance contract authority, Autonomy authorize, Command Bus execute, Rewind recover, and Wisdom learn. The registry is non-authoritative, uses `company_id`, and every consequential execution gate fails closed. Governance may only contract authority before Autonomy; it cannot expand it.

## Integrated Upgrade Pass 11 — Full Ecosystem Capability Registry

Pass 11 imports and normalises the real capability surfaces from all 28 supplied Titan providers into a provenance-bound registry. The catalogue records capabilities, tools, commands, signals, data sources, workflows and intrinsic-role bindings while preserving provider ownership. Static catalogue entries grant no authority: runtime activation requires the declared provider service class to be installed, and consequential execution remains governed by Risk, Assurance, Governance and Autonomy.


## Integrated Upgrade Pass 10 — Workforce Capability Binding

Pass 10 separates **Workforce-owned employee identity** from **extension-owned execution surfaces**. The intrinsic/executive Workforce catalogue is now the sole canonical employee source, while extensions contribute capabilities, tools, commands, signals, data sources and workflows through `titan.workforce.capability-bindings.v1`. Manifest 2.0 role blocks remain readable only as compatibility binding hints and cannot create canonical employees. Capability-provider provenance is recorded independently from `role_owner_extension`, and no binding inherits authority or bypasses Risk, Assurance, Governance or Autonomy.


## Integrated Upgrade Pass 9 — Intrinsic Responsibilities

Pass 9 restores 114 canonical Workforce-owned accountabilities across all 111 intrinsic roles. Responsibilities now exist independently of installed capability providers, use stable `titan.responsibility.*` identities, and remain non-executable (`capability_authority=NONE`, no authority inheritance). The historical human-readable responsibility text is preserved for compatibility while canonical `responsibility_ids` drive the first-class role/accountability mapping. Scheduled and event-driven proactive routines remain deferred to later passes.


## Integrated Upgrade Pass 8 — Teams & Department Composition

Pass 8 replaces the old flat `*-core` team placeholders with 61 canonical practical operational teams across all 15 intrinsic divisions. Every one of the 111 intrinsic roles is bound to exactly one same-division `titan.team.*` definition. Workforce Bootstrap materialises definition-backed division/team containers for a company without hiring employees; external Manifest 2.0 teams remain compatibility-only additions and cannot redefine intrinsic teams.


## Integrated Upgrade Pass 7 — Organisational Graph & Reporting

Pass 7 establishes the intrinsic seven-type organisational graph (`reports_to`, `manages`, `coordinates`, `consults`, `informs`, `delegates_to`, `escalates_to`) as canonical Workforce-owned relationship definitions. Existing active members are synchronised only when both endpoints exist; no staff are auto-hired and no relationship inherits execution authority. Graph validation rejects reporting cycles, self-links, orphan manager references and cross-company edges, while the organisation-graph API exposes a live integrity verdict.


## Integrated Upgrade Pass 6 — AI Business Manager & Executive Layer

- Adds canonical `titan.executive.business_manager` directly beneath Titan Zero and above all 15 intrinsic division managers.
- Preserves Operations Manager as the daily cross-division operational coordinator while moving overall executive accountability to the AI Business Manager.
- Disambiguates the historic internal `Chief of Staff` role as **Executive Operations Coordinator**, retaining `Chief of Staff` as a compatibility alias; Titan Zero remains the only owner-facing Chief of Staff.
- Executive relationships explicitly set `authority_inherited=false`; the AI Business Manager receives zero domain executable capabilities and cannot bypass Risk, Assurance, Governance or Autonomy.
- Pass 6 synchronises already-active executive/manager instances only; it does not auto-hire the AI Business Manager or any division manager.

## Integrated Upgrade Pass 3 — Restore the 15 Intrinsic Divisions

- Restores the v0.5 intrinsic 15-division organisation as canonical Workforce-owned definitions.
- Preserves each historical division key, name and purpose while adding stable `titan.division.*` identity, canonical manager-role references, team-boundary descriptors, applicability and activation rules.
- Adds `ext_titan_ai_workforce_division_definitions` and binds any pre-existing company division instance to its canonical definition without creating or auto-activating new company divisions.
- All Pass-3 activation rules set `auto_activate=false`; actual role restoration, team activation and business routines remain assigned to later passes.
- External extensions remain capability/tool/signal/execution providers and do not regain organisational ownership.

## Integrated Upgrade Pass 2 — Canonical Workforce Domain

- Workforce now canonically owns organisation, roles, responsibilities, work items, actions, triggers, councils, delegation, escalation, evidence, outcomes and performance.
- `role_definition_id` is the sole Workforce role identity; autonomous AI employees no longer inherit the activating human `user_id`.
- `task.vertical` and `task.workflow_ref` are canonical runtime sources, with one-time legacy metadata backfill.
- New domain tables are additive and remain unpopulated until the dedicated intrinsic-team restoration passes.
- External extensions remain capability/tool/signal/execution providers rather than organisational authorities.



## Integrated Upgrade Pass 5 — Titan Zero Chief of Staff

Titan Zero is now a permanent `SYSTEM` RoleDefinition and one idempotently ensured per-company Chief-of-Staff member. It consumes no staffing seat, has organisation-wide company-scoped visibility and coordination permissions, carries zero domain executable capabilities, cannot be suspended/retired through ordinary staff lifecycle operations, and cannot request bypasses around Risk, Assurance, Governance or Autonomy. Ordinary manager/proactive/manifest-lifecycle loops exclude the system role until the executive layer is introduced in Pass 6.

## Integrated Upgrade Pass 4 — Restore 111 Intrinsic Roles

- Restores all 111 v0.5 role identities as canonical `role_definition_id` definitions owned by Workforce.
- Adds purpose, tier, division/team identity, responsibilities, canonical reporting relationships, recommended skills, vertical applicability and recommended business maturity.
- The historic role-level capability labels are translated into non-authoritative skill descriptors only; executable capabilities remain extension-bound.
- No WorkforceMember rows are auto-created and every role remains `auto_activate=false`.
- Operations Manager remains the temporary root until the explicit executive-layer pass introduces Titan Zero / AI Business Manager coordination.

## Integrated Upgrade Pass 1 — Baseline Preservation & Ecosystem Map

- Runtime behavior is byte-preserved from v0.27.0-alpha.27; this pass adds evidence/provenance only.
- v0.5.0-alpha.5 is frozen as the intrinsic-team donor (15 divisions / 111 roles / 19 scheduled / 44 event routines).
- All 28 canonical supplied extension identities are inventoried with capability ownership, signals, compatibility blockers and migration classifications under `docs/pass1/`.
- Workforce remains `company_id` canonical and no dependency, authority or write-path contract is weakened in this pass.


Titan AI Workforce is Titan's **canonical organisational registry and orchestration layer**. It owns the intrinsic organisation, division definitions and role definitions, while installed extensions contribute executable capabilities, tools, signals, workflows and domain execution surfaces. Workforce provides instantiated staff organisation, persistent tasks, queues, schedules, reviews, handoffs, workload sharing, Workforce Planning, maturity/performance and the Control Room.

It does **not** implement Titan Risk, Assurance, Autonomy, Signal, Command Bus, Council, Wisdom, Rewind, Knowledge, Shield, Forge, Nexus, Prime or Vertical Engine. It consumes those systems through small contracts/adapters.

## Production Upgrade Pass 9 — Three-Way Chain-of-Command v2

- Maker output requires independent originating-Manager review before consequential cross-division handoff.
- Handoffs freeze a canonical SHA-256-bound packet containing source result/evidence/governance, routing and trace context.
- Receiving Managers independently accept responsibility or return work for revision; repeated/conflicting decisions are serialized and fail closed.
- Acceptance creates a new receiving-side child task and new governed cycle; the originating task is never repurposed as receiving work.
- Task parents must exist in the same tenant, dependency links reject transitive cycles, and `titan.workforce.chain-integrity` exposes orphan/cycle health.
- Task history is append-only and handoff packet/routing fields are immutable.


## Production Upgrade Pass 3 — Workforce Manifest 2.0

- Canonical extension-owned Workforce discovery now requires schema `2.0`.
- Blueprint-compatible schema `1.1` remains bounded legacy input and is normalised to 2.0 using autonomy-band floor scores only.
- Schema 1.0 is no longer silently accepted.
- Invalid contributors are quarantined independently and cannot create activatable roles.
- Manifest health is exposed through `titan.workforce.manifest-health` and the authenticated `api/manifest-health` route.
- Every discovered role retains owning extension/version, canonical/source schema versions, definition version and a deterministic definition fingerprint.
- Effective authority and predictive readiness remain external Titan Autonomy outputs.

## Production Upgrade Pass 4 — Extension-Owned Registry Lifecycle

- Instantiated staff and newly assigned tasks now pin exact owner extension, owner version, role definition version, canonical fingerprint and a role-definition snapshot.
- Extension activation/upgrade/disable/uninstall invalidates the central registry through `titan.workforce.manifest-lifecycle`.
- Missing source extensions make affected staff unavailable without deleting or remapping them. Historical tasks, receipts, reviews, handoffs and Rewind references remain intact.
- Additive role changes are marked `COMPATIBLE` and remain pinned until explicit rebind; removed capabilities/tools/workflows or structural/authority contractions are `BREAKING` and fail closed.
- Exact extension key + role ID is the lifecycle identity. Display names and aliases are never used to remap historical staff.
- A 30-day compatibility/deprecation window is recorded for changed definitions; it does not grant new authority.
- `titan-workforce:reconcile-definitions` provides an operator reconciliation path after extension lifecycle changes.



## Production Upgrade Pass 8 — Organisational Graph, Deputies & Decision Rights

- Reporting lines are persisted as an acyclic tenant graph; manager reassignment rejects cycles before mutation and keeps `manager_id`, `reports_to`, `manages` and `reviews_for` aligned.
- Extension-owned Workforce Manifest 2.0 `raci` entries are the source of decision rights. Central Workforce no longer ships domain-specific RACI rows.
- Deputies must be active same-division Tier-1 Managers with explicit scope and a future expiry. `authority_inherited=false`; the deputy must satisfy its own Titan Autonomy decision.
- Cross-division direct delegation is rejected; cross-division responsibility moves only through governed handoff.
- Organisational disputes require explicit participant Manager IDs and escalate to the first unambiguous common Manager in the persisted reporting graph; otherwise `HUMAN_DECISION_REQUIRED`.

## Workforce definition ownership

- **111 bundled canonical intrinsic role definitions**
- **15 bundled canonical intrinsic division definitions**
- **0 bundled generic Action Worker definitions**
- Domain extensions continue to contribute executable capabilities/tools/signals/workflows through Workforce manifests; organisational role/division identity is intrinsic to Workforce.
- The v0.5 111-role suite is restored as live canonical definitions with no automatic employee activation.
- Legacy role capability labels are retained only as non-authoritative recommended skill descriptors; executable authority remains external and governed.
- Existing instantiated staff/tasks/history are retained across upgrades; missing/disabled source definitions become unavailable rather than silently reassigned.

## Pass 3 — Manager Operations

- Tier-1 Manager objectives are decomposed into deterministic Tier-2 specialist plans.
- Plans are rejected if they contain unknown roles, capability mismatches, reporting-line violations, direct cross-division assignment or dependency cycles.
- Specialist selection considers active status, role, capability, risk ceiling and concurrent workload.
- Blocking task dependencies are persisted and released only when prerequisites complete.
- Cross-division work preserves the originating task, requires receiving-Manager acceptance, then creates a fresh receiving specialist task and a new governed cycle.
- Scoped deputies can review only while the assigned Manager is unavailable; deputy relationships never inherit business authority.
- Daily Ops Council / Weekly Performance Review and dispute escalation create normal governed Workforce objectives only.
- Queue jobs are unique by tenant+task to prevent duplicate concurrent processing.

## Compatibility

Former BlogPilot tables are not recreated, mutated or auto-imported. `LegacyBlogPilotImportService` can explicitly import selected legacy records only when an authoritative `company_id` is supplied.

See `docs/AI-WORKFORCE-BUILD-PLAN.md` for the cumulative plan.


## Pass 4 — Proactive Divisions

- Data-driven proactive responsibility registry; no per-role runtime duplication.
- Every division Manager receives weekday morning operating briefs and day-end exception sweeps.
- Every Specialist receives a low-cost weekly responsibility review; high-value roles additionally receive targeted schedules and Titan Signal event triggers.
- 39 event-triggered routines cover customer, sales, work, money, people, assets, procurement, records, automation, governance, hospitality/real estate, commerce and rental workflows.
- Optional vertical packs cover field services, hospitality, real estate, commerce, rental and appointment/membership businesses.
- Queue Health monitors capacity, overdue work, blocked work, starvation and coverage gaps without replacing Titan Risk.
- Proactive Managers may rebalance only unstarted ASSIGNED work within their own division and only to capability/risk-compatible staff.
- Staffing pressure is fed into Workforce Planning; role activation remains recommendation-only (`auto_activate=false`).
- Proactive playbooks are references only. Business mutation remains governed by external Titan Risk, Assurance, Autonomy and Command Bus.


## Pass 5 — Governed Intelligence Loop

- Risk, Assurance and Autonomy are all required to return authoritative pre-execution decisions before consequential execution may proceed. Missing engines fail closed.
- Referenced Interaction Engine workflows are prepared through an adapter and block execution if the required workflow cannot be resolved.
- The governance envelope now carries role-definition identity, manager/division context, playbook/workflow references, evidence, capability and full trace/correlation/causation identifiers.
- Command Bus success is not enough: a completed mutation requires an authoritative execution receipt. Missing receipts enter RECOVERY for reconciliation.
- Successful receipts are forwarded to Titan Rewind and real outcomes to Titan Wisdom through optional adapters, then recorded as structured Workforce references.
- Titan Signal outcome events preserve the same trace/correlation chain. Signal-triggered tasks cite the triggering signal directly as `causation_id`.
- Division and organisation trust-health summaries expose Risk, Assurance, Autonomy availability and blocked/recovery/escalated work without recalculating authoritative engine decisions.
- Titan Vertical Engine overlays may specialise terminology, procedures, knowledge and capability variants, but cannot silently raise risk ceilings, add authority or inject new capabilities.
- External Risk/Assurance/Autonomy/Wisdom execution signals can create governed follow-up work for the appropriate Governance/Insights staff.


## Pass 6 — Control Room & Final Certification

- Added a Workforce Control Room for live organisation, Manager queues, Risk/Assurance/Autonomy trust state, approvals, handoffs, staffing recommendations, performance and Rewind/Wisdom outcome references.
- Workforce Planning recommendations are persistent and reviewable. Approval never creates a staff member and never changes Autonomy; it opens the existing Employee Builder for explicit activation.
- Staff performance derives from persistent task/review history. Maturity recommendations are evidence-based organisational experience only.
- Missing explicit Assurance calibration remains visible as missing evidence instead of being inferred from confidence.
- Added a Workforce-side cross-extension acceptance matrix that distinguishes proven Workforce controls from peer-engine live integration gates.

## Workforce definition ownership (0.6.1)

Titan AI Workforce is the central **registry/orchestrator**, not the source of domain employees. Capability-owning Titan extensions ship their own `resources/workforce/workforce-manifest.json` and contribute it to `titan-workforce.manifests`. This package bundles no domain role catalogue, no domain division catalogue, and no generic Action Worker pack. Existing organisational/task/history data is retained.


## Pass 1 — Blueprint v4 / Step-10 Baseline Conformance

See `docs/BLUEPRINT-STEP10-BASELINE-CONFORMANCE.json` for the machine-readable baseline lock used by the v1.0.0 production upgrade plan.


## Pass 2 — Installer 1.7.8 & Manifest 2.2 Packaging

- Root `extension.json` is now the exact minimal Installer 1.7.8 deployment manifest.
- Architectural metadata moved exclusively to canonical `extension.manifest.json` schema 2.2.
- `integrity.files` covers every regular package file except `extension.json`, preventing circular self-hashing.
- Added self-contained Step-10 manifest builder, flat-ZIP packager and ZIP verifier.
- Workforce Manifest discovery remains on the existing v1 contract until Pass 3; this pass does not change workforce runtime semantics.

## Production Upgrade Pass 5 — Self-Healing Parent/Child Host Navigation

- AI Workforce keeps one `AI Workforce` parent dropdown with seven child links: Overview, Team, Work, Schedule, Control Room, Performance and Add Staff Member.
- Modern hosts receive `navigation.user` contributions through `MenuContributionRegistry` (or the generic contribution registry when that is the only registry exposed).
- MagicAI hosts without a compatible contribution registry self-heal through the `menus` table. The parent is persisted first, its real database `id` is resolved, and each child is repaired against that exact `parent_id`.
- Existing administrator-controlled order and enabled/disabled state are never overwritten during repair. Vendor-owned route/label/icon/type/parent structure may be repaired.
- Operational Workforce rows persist `extension = NULL`, avoiding accidental MagicAI plan-feature filtering.
- Duplicate host menu keys are not deleted automatically; only the canonical first row is repaired and the anomaly is logged.
- `php artisan titan-workforce:host-sync` provides an explicit install/upgrade/operator repair path and forces `MenuService::regenerate()` when the host exposes it.
- Navigation compatibility is fail-open for UI boot only: menu repair failure cannot break Workforce runtime or grant authority.


## Pass 7 — Staff Instance Lifecycle v2

See `docs/PASS07-STAFF-INSTANCE-LIFECYCLE-V2.md`. Staff activation now requires an exact valid extension-owned RoleDefinition, authority-bearing fields are manifest-owned, lifecycle state is separate from operational status, and suspension/retirement preserve historical provenance.

## Production Upgrade Pass 10 — Proactive Workforce Runtime v2

- Proactive duties are sourced exclusively from installed extensions' Workforce Manifest schedules and Signal triggers.
- Generated schedules persist owning extension, owner version, RoleDefinition, definition fingerprint, routine ID, routine fingerprint and source schema provenance.
- Schedule occurrence and Signal delivery identities are deterministic and replay-safe; task creation uses the database idempotency boundary and only newly created tasks are queued.
- Due schedule rows are locked before dispatch so concurrent scheduler workers cannot advance the same occurrence twice.
- Staff timezone settings control schedule calculation; due timestamps remain stored in application UTC.
- Extension disable/uninstall immediately stops owned proactive work, while activation/upgrade resynchronises active staff definitions.
- Queue health exposes capacity utilisation, starvation, SLA/coverage pressure and staffing-pressure signals to Workforce Planning.
- Proactive Manager coordination requires a valid installed extension-owned Tier-1 Manager definition.
- Proactivity creates Workforce Tasks only. It does not directly execute authoritative business mutations or bypass Risk, Assurance, Autonomy, Interaction or Command Bus.

## Production Upgrade Pass 11 — Continuous Titan Autonomy

- Titan Autonomy Decision v2 is consumed as the external authority contract on a continuous 0–100 scale.
- Every decision is bound to exact tenant, Workforce member, capability, capability variant, vertical, workflow and contextual fingerprint.
- Workforce validates Decision v2 invariants and may only reduce/deny authority; it never calculates earned authority or raises effective authority.
- Extension-owned capability minimums are enforced as numeric score/band requirements. Central Workforce capability metadata now uses the same continuous contract.
- Predictive execution requires both capability-specific Predictive authority and separate Predictive readiness; there is no global Trusted Auto/Predictive switch.
- Offline policy can block execution or apply an explicit lower authority cap and can never raise authority.
- Model/provider preference changes produce a new context fingerprint and `MODEL_PROVIDER_CHANGED` re-evaluation reason without globally resetting unrelated evidence.
- Workforce persists only Autonomy decision references/fingerprints on staff. Maturity, hierarchy, deputy coverage and staffing state do not become authority inputs.


## Production Upgrade Pass 12 — Risk, Assurance, Model Council & Interaction

- Consequential execution consumes explicit external Titan Risk and Titan Assurance decisions; there are no permissive Workforce fallbacks.
- Risk is carried as Minimal/Low/Medium/High/Extreme with contextual, cumulative, vertical and residual references; Assurance is Green/Amber/Red with structured evidence references.
- Model Council is invoked only when Risk or explicit policy requires it. If required and unavailable or unsatisfied, execution fails closed.
- Required capability evidence is compared with structured task evidence. Missing evidence resolves an owning-extension Interaction workflow/Wizard and moves the task to AWAITING_DATA.
- Green Assurance cannot override a Risk denial. Workforce validates and enforces external decisions but does not calculate Risk, Assurance or Council consensus.
- New handoff packets carry explicit evidence references alongside governance snapshots so receivers review the same decision evidence.

### v0.20.0-alpha.20 — Pass 14: Signal, Rewind, Wisdom & Outcome Feedback Spine

Pass 14 adds an append-only structured journey spine for task/review/handoff/escalation/staffing/execution/outcome events. The same reference-safe records flow through Titan Signal and Titan Rewind; verified authoritative outcomes only are forwarded to Titan Wisdom and as evidence to Titan Autonomy. Hidden/private reasoning is filtered, outcome feedback cannot change authority directly, and missing/late post-action verification is surfaced through outcome health and the Control Room.


## Coordinated Upgrade Pass 1 — Three-Bundle Baseline & Architecture Freeze

See `docs/PASS15-COORDINATED-PASS01-ARCHITECTURE-FREEZE.md` and the machine-readable `docs/TITAN-THREE-SYSTEM-ARCHITECTURE-FREEZE.json`. This pass freezes the three-system authority model without changing runtime behaviour. The target canonical company boundary is `company_id`; the current `company_id` persistence is explicitly legacy and is migrated in coordinated Pass 2.
## Coordinated Pass 3 — Runtime Contract Layer

Workforce owns the versioned `titan.agent-runtime/1` orchestration port. Existing Titan AI behavior is preserved behind a compatibility adapter until Titan Agent Runtime extraction in coordinated Pass 4. Runtime output is non-authoritative and tool calls are proposals only.

## Coordinated Pass 5 — Workforce Member ↔ Runtime Profile Binding

- Titan AI Workforce now owns the company-scoped runtime-profile store and the authoritative Workforce member → runtime profile binding.
- Existing members receive additive proposal-only default profiles with no consequential tool authority; new/imported members are bound during lifecycle creation.
- Workforce tasks inherit the selected member profile and fail closed if a task attempts to substitute a different runtime profile.
- Runtime profile payloads carry provider/model policy, persona/system prompt, memory/channel/reasoning policy and informational-tool declarations while consequential execution authority remains `none`.
- Titan Agent Runtime must consume the exact Workforce-selected `runtime_profile_id`; it may not silently select a default profile.
- Titan Hub, Titan BOS, Titan Go and AI Chat Pro surface profiles remain presentation/routing identities only and never impersonate Workforce runtime profiles.
- The shared `titan.agent-runtime/1` schema remains byte-stable; the new profile-selection invariant is enforced at the Workforce/Runtime execution boundary.



## UI Step 5 — Work Command Center

- Work is now a multi-view orchestration surface: List, Kanban, Timeline, Dependency graph, Manager review, Handoff queue, Escalations and Recovery.
- Every task has a dedicated evidence-complete detail workspace for ownership, responsibility, hierarchy, dependencies, evidence/reviews, capability requirements, governance snapshots, execution attempts/receipts, outcomes, journey trace and immutable history.
- All views are company-scoped read projections; visibility, queue state and capability requirements never grant execution authority.

## UI Step 6 — Visual Work Graph

- Complex autonomous work now has a dedicated visual graph reached from each task detail workspace.
- The graph projects seven distinct node types: task, decision, review, handoff, execution, evidence and outcome.
- Parent/child and task dependency relationships connect work items; governed records attach to the authoritative task spine.
- SVG connectors are generated from server-produced graph edges, with a textual edge list retained for accessibility and diagnostics.
- Graph visibility is company-scoped and read-only; graph membership, evidence, provider state and execution records never grant authority.


## UI Step 8 — Responsibilities Center

- Adds a first-class Responsibilities Center covering all 114 canonical intrinsic responsibilities.
- Each responsibility exposes canonical owner role, eligible/assigned employee, division/team, purpose, trigger/schedule state, role-bound capability requirements, live provider health, authority requirements, recent generated work and recent outcomes.
- Company-specific management is stored in a dedicated `company_id`-scoped override table so canonical/global responsibility definitions are never mutated by one company.
- Operators may enable/disable, tune schedule JSON, adjust trigger-condition JSON and reassign only to employees holding an allowed canonical owner role.
- Responsibility overrides contain no capability or authority grant fields; `authority_inherited=false` and `execution_authority_granted=false` remain explicit invariants.

## UI Step 7 — Manager Command Center

- Every Tier-1 Workforce Manager now has a dedicated operational home for team availability, reviews, escalations, handoffs, blocked work, workload balance, staffing, proactive schedules and verified outcomes.
- The governed action dock exposes approve/revision, delegation, reassignment, decomposition, escalation, deputy appointment and deadlock resolution through existing Workforce services/routes.
- Escalation is now a first-class manager action that transitions the governed task and persists a company-scoped WorkforceEscalation record.
- Manager Command Center projections remain read-only authority-wise: workload, availability, hierarchy, deputy coverage and escalation never inherit or expand execution authority.

## New Roadmap Step 2 — Workforce Attention Center

Adds a company-wide intervention inbox across workforce health, work, governance, execution, outcomes and staffing. Items are ranked by severity × business impact × age × blocking effect and link back to the authoritative Workforce object for resolution. The inbox is a read-only projection and never grants authority.

## New roadmap Step 14 — Workforce Conversational Interface
- Completes the previously empty/null Titan AI Workforce conversation adapter.
- Adds Ask Workforce for company-scoped operational questions.
- Explicit `Ask <employee or role> to <work>` language creates a persistent governed Workforce Work Item only.
- Conversation never claims authoritative business execution and never grants/inherits authority.
- Conversation-created work requires fresh capability, Risk, Assurance, Governance and Autonomy authorization before consequential execution.

## 31-Provider Full Platform Convergence

This build merges the release-readiness Workforce branch with the canonical full-platform integration layer and adds Titan People, Titan Payroll and TitanTrust. Workforce remains the sole organisational identity/role/responsibility owner. The three providers contribute governed business-domain execution/read surfaces only. The combined registry contains 31 unique providers and deterministic provider/version routing remains mandatory for executable work.
