# Pass 13 — Command Bus Execution, Receipts, Recovery & Post-Action Verification

## Scope

Pass 13 hardens the boundary between approved Workforce intent and authoritative business mutation. Titan AI Workforce still does **not** own CRM, payments, bookings, inventory or other domain state. Capability-owning extensions define the capability contract and Titan Command Bus remains the only mutation boundary.

## Persist intent before side effect

Before any consequential dispatch Workforce now creates or reuses an append-only execution attempt. The attempt binds the tenant, task, worker, owning extension capability, command payload, expected authoritative state, a deterministic state fingerprint, an immutable intent SHA-256 and a stable Command Bus idempotency key.

This is the **intent lock**. The lock is persisted before the external side effect.

## Pre-execution state revalidation

After governance approval and before dispatch, Workforce asks Command Bus to revalidate the authoritative domain state against the exact expected state bound into the intent. A state mismatch is `STATE_CHANGED` and execution fails closed before mutation. Missing state-revalidation support also fails closed; Workforce never substitutes a cached CRM/model read.

## Idempotent Command Bus dispatch

The dispatch envelope carries `intent_id`, `intent_sha256`, `state_fingerprint`, `idempotency_key` and `expected_state`. An ambiguous transport error is treated as **uncertain execution**, not as permission to resend.

## Authoritative receipt

A successful mutation is not accepted without a structured receipt that matches the locked tenant, task, capability, intent ID/hash and idempotency key. The receipt itself is SHA-256 bound in the attempt ledger. A missing or mismatched receipt moves the task to `RECOVERY`.

## Uncertain execution recovery

Recovery asks Command Bus to `reconcileReceipt`/reconcile the original idempotency key. A matching receipt may recover the execution without redispatch. No receipt means `RECOVERY_REQUIRED`; Workforce does not blindly retry.

## Post-action verification

Receipt existence is not sufficient. Command Bus/domain capability verification must confirm the authoritative post-action result through `verifyReceipt`/verification. The result can carry a `domain_state_ref`. Failed or unavailable post-action verification keeps the task in `RECOVERY`, never `COMPLETED`.

## Compensation and reversibility

The capability-owning extension declares `reversible`, `compensatable` or `irreversible`. Recovery exposes compensation only for reversible/compensatable capabilities and routes it back through Command Bus. Irreversible actions require human decision; Workforce does not invent a rollback.

## Fail closed guarantees

- state changed → no dispatch;
- Command Bus unavailable → no mutation;
- uncertain dispatch → reconcile, do not resend;
- missing/invalid receipt → recovery;
- failed post-action verification → recovery;
- irreversible failed verification → human recovery path;
- no direct CRM/domain-model writes are introduced by Workforce.

The execution-attempt ledger is organisational evidence for Rewind, incident response and later outcome learning. It is not a second business-state authority.
