# Complaint runtime disabled

The executable donor was quarantined in Pass 3. Use `CustomerFeedback` for runtime behavior.

Source archive: `LegacyDonors/Complaint-Pass2-Source.zip`.
