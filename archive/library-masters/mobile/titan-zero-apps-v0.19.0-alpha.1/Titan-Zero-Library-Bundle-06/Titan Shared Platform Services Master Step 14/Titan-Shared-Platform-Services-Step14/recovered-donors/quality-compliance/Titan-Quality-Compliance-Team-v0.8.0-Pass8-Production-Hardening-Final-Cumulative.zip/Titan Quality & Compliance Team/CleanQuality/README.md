# CleanQuality compatibility descriptor

The executable CleanQuality donor was quarantined in Pass 2 after its useful Filament, action and AI-tool concepts were merged into canonical QualityControl implementations. The complete pre-convergence source is preserved at `LegacyDonors/CleanQuality-Pass1-Source.zip`.

This descriptor intentionally contains no PHP runtime. Legacy CleanQuality URLs are bridged explicitly by QualityControl.
