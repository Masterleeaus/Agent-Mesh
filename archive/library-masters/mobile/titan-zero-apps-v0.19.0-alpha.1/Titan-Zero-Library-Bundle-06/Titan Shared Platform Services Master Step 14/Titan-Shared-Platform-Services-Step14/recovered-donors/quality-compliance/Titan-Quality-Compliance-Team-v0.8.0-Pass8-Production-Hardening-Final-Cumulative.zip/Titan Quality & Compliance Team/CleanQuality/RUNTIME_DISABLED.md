# CleanQuality runtime disabled

CleanQuality is preserved as a donor/compatibility source only. **QualityControl** is the sole runtime owner of inspection schedules, templates, QC records, corrective actions, reclean lifecycle, reporting and UI after convergence Pass 2.

This module intentionally registers no providers, routes, migrations, events or scheduled commands. Legacy URLs are bridged explicitly by `QualityControl/Routes/web.php`.
