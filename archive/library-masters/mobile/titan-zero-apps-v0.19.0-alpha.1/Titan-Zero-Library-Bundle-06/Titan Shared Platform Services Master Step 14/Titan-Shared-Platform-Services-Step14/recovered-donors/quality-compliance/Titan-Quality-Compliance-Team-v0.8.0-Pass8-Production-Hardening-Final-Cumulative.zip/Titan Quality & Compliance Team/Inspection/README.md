# Inspection compatibility descriptor

The executable Inspection donor was quarantined in Pass 2 because QualityControl now owns the entire quality/inspection runtime and the donor contained parse-broken placeholder PHP. The complete pre-convergence source is preserved at `LegacyDonors/Inspection-Pass1-Source.zip`.

Legacy inspection URLs and route names are served by QualityControl. This descriptor intentionally contains no PHP runtime.
