import type { VisitStatus, WorkOrderStatus } from "./statuses";
import { allRequiredCriteriaMet, type CompletionCriterion } from "./completion-criteria";

export interface WorkOrderVisitSnapshot {
  status: VisitStatus;
  scheduled_start: string | Date;
  /** Field closeout fork. NULL/omitted = legacy Complete. */
  closeout_kind?: "done" | "return" | null;
}

export interface DeriveWorkOrderStatusInput {
  currentStatus: WorkOrderStatus;
  visits: WorkOrderVisitSnapshot[];
  completionCriteria: CompletionCriterion[];
  /** Defaults to now(). Injectable for tests. */
  now?: Date;
}

const ACTIVE_FIELD_STATUSES: readonly VisitStatus[] = [
  "dispatched",
  "traveling",
  "arrived",
  "in_progress",
  "waiting",
];

const TERMINAL_VISIT_STATUSES: readonly VisitStatus[] = ["completed", "cancelled"];

/**
 * Pure derivation of work order planning status from child visits and criteria.
 * Manual holds (`waiting`, `cancelled`) are respected unless completion is fully met.
 */
export function deriveWorkOrderStatus({
  currentStatus,
  visits,
  completionCriteria,
  now = new Date(),
}: DeriveWorkOrderStatusInput): WorkOrderStatus {
  if (currentStatus === "cancelled") return "cancelled";
  if (currentStatus === "draft") return "draft";

  const allVisitsDone =
    visits.length > 0 &&
    visits.every((v) => TERMINAL_VISIT_STATUSES.includes(v.status)) &&
    visits.some((v) => v.status === "completed");

  if (allVisitsDone && allRequiredCriteriaMet(completionCriteria)) {
    const latestCompleted = [...visits]
      .filter((v) => v.status === "completed")
      .sort(
        (a, b) =>
          new Date(b.scheduled_start).getTime() - new Date(a.scheduled_start).getTime(),
      )[0];
    // Coming back with no next visit planted must not auto-complete the WO.
    if (latestCompleted?.closeout_kind === "return") {
      return currentStatus === "waiting" ? "waiting" : "dispatched";
    }
    return "completed";
  }

  if (allVisitsDone && !allRequiredCriteriaMet(completionCriteria)) {
    return "dispatched";
  }

  if (currentStatus === "waiting") return "waiting";

  const hasActiveField = visits.some((v) => ACTIVE_FIELD_STATUSES.includes(v.status));
  if (hasActiveField) return "dispatched";

  const hasFutureScheduled = visits.some((v) => {
    if (v.status !== "scheduled") return false;
    const start = v.scheduled_start instanceof Date ? v.scheduled_start : new Date(v.scheduled_start);
    return start.getTime() > now.getTime();
  });
  if (hasFutureScheduled) return "scheduled";

  const hasAnyScheduled = visits.some((v) => v.status === "scheduled");
  if (hasAnyScheduled) return "scheduled";

  return "ready";
}

/** UI label when visits are active but WO DB status is still planning-phase. */
export function derivedWorkOrderUiLabel(
  dbStatus: WorkOrderStatus,
  visits: WorkOrderVisitSnapshot[],
): string | null {
  if (dbStatus === "completed" || dbStatus === "cancelled" || dbStatus === "draft") {
    return null;
  }
  const hasActive = visits.some(
    (v) => v.status === "in_progress" || v.status === "arrived" || v.status === "traveling",
  );
  if (hasActive && dbStatus !== "dispatched") return "In Progress";
  return null;
}