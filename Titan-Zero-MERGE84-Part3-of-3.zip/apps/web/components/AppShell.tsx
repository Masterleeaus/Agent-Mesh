"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useRef, useState, type ReactNode } from "react";
import type { Route } from "next";
import type { Role } from "@ai-fsm/domain";
import { ToastProvider } from "./ui/Toast";
import { QuickLeadModal } from "./QuickLeadModal";
import { FloatingActionButton } from "./FloatingActionButton";
import { CAPTURE_HREF, CaptureLink } from "./CaptureLink";
import { WorkspaceAutoRoute } from "./WorkspaceAutoRoute";
import { LiveRefresh } from "./LiveRefresh";
import { ConnectionStatus } from "./ConnectionStatus";
import { GlobalSearch } from "./GlobalSearch";
import {
  IconDashboard,
  IconEstimates,
  IconInbox,
  IconSettings,
  IconMyDay,
  IconProperties,
  IconJobs,
  IconClients,
  IconInvoices,
  IconReports,
  IconVisits,
  IconSchedule,
  IconQueue,
  IconDayReview,
  IconField,
  IconCapture,
} from "./NavIcons";
import {
  AttentionBell,
  NavCountBadge,
  useAttentionSummary,
} from "./attention/AttentionBell";

type IconComponent = (props: { size?: number }) => React.ReactElement;

function IconChevronLeft({ size = 14 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <polyline points="15 18 9 12 15 6" />
    </svg>
  );
}

function IconChevronRight({ size = 14 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <polyline points="9 18 15 12 9 6" />
    </svg>
  );
}

interface NavItem {
  href: string;
  label: string;
  Icon: IconComponent;
  adminOnly?: boolean;
  /** Extra path prefixes that mark this item active (mobile hub tabs). */
  activePrefixes?: string[];
}

interface NavSection {
  label: string;
  items: NavItem[];
}

// ---------------------------------------------------------------------------
// Navigation definitions — ONE model. Nested hubs (Home / Work / People / Money).
// Sidebar (≥768px) and More sheet (<768px) render the same sections; the bottom
// bar is a 4-hub shortcut subset (+ More button in AppShell).
// ---------------------------------------------------------------------------

// The office overview/dashboard. Labelled "Overview" (not "Today") so it reads
// as the numbers screen and doesn't compete with the My Day field surface.
const NAV_TODAY:      NavItem = { href: "/app",              label: "Overview",   Icon: IconDashboard };
// EPIC-006 Phase 5: the field surface. Owners can switch into it; pure admins
// (who don't do field work) and the all-techs list never see it here.
const NAV_MY_DAY:     NavItem = { href: "/app/my-work",      label: "My Day",     Icon: IconMyDay };
const NAV_CAPTURE:    NavItem = { href: "/app/capture",      label: "Capture",    Icon: IconCapture };
const NAV_DAY_REVIEW: NavItem = { href: "/app/day-review",   label: "Day Review", Icon: IconDayReview };
const NAV_TRACKING:   NavItem = { href: "/app/timeline",     label: "Tracking",   Icon: IconField };
const NAV_REQUESTS:   NavItem = { href: "/app/requests",     label: "Requests",   Icon: IconInbox };
const NAV_CLIENTS:    NavItem = { href: "/app/clients",      label: "Clients",    Icon: IconClients,   adminOnly: true };
const NAV_PROPS:      NavItem = { href: "/app/properties",   label: "Properties", Icon: IconProperties, adminOnly: true };
const NAV_ESTIMATES:  NavItem = { href: "/app/estimates",    label: "Estimates",  Icon: IconEstimates, adminOnly: true };
const NAV_JOBS:       NavItem = { href: "/app/jobs",         label: "Jobs",       Icon: IconJobs,       adminOnly: true };
const NAV_WORK_ORDERS: NavItem = { href: "/app/work-orders", label: "Work Orders", Icon: IconQueue,     adminOnly: true };
const NAV_SCHEDULE:   NavItem = { href: "/app/schedule",     label: "Schedule",   Icon: IconSchedule,  adminOnly: true };
const NAV_INVOICES:   NavItem = { href: "/app/invoices",     label: "Invoices",   Icon: IconInvoices,  adminOnly: true };
const NAV_REPORTS:    NavItem = { href: "/app/reports",      label: "Reports",    Icon: IconReports,   adminOnly: true };
const NAV_SETTINGS:   NavItem = { href: "/app/settings",     label: "Settings",   Icon: IconSettings,  adminOnly: true };

/** Nested hub IA — Home / Work / People / Money (+ Settings). Home item is injected per role/view. */
function buildHubSections(home: NavItem): NavSection[] {
  return [
    { label: "Home", items: [home, NAV_CAPTURE, NAV_DAY_REVIEW, NAV_TRACKING] },
    {
      label: "Work",
      items: [NAV_REQUESTS, NAV_ESTIMATES, NAV_JOBS, NAV_WORK_ORDERS, NAV_SCHEDULE],
    },
    { label: "People", items: [NAV_CLIENTS, NAV_PROPS] },
    { label: "Money", items: [NAV_INVOICES, NAV_REPORTS] },
    { label: "", items: [NAV_SETTINGS] },
  ];
}

// ---------------------------------------------------------------------------
// Pure functions
// ---------------------------------------------------------------------------

/** Returns filtered nav sections for a given role and active workspace view. */
export function getNavSections(role: Role, view: "office" | "field" = "field"): NavSection[] {
  if (role === "tech") {
    const myDay: NavItem = { href: "/app/my-work", label: "My Day", Icon: IconMyDay };
    const visits: NavItem = { href: "/app/visits", label: "Visits", Icon: IconVisits };
    return [{ label: "", items: [myDay, visits, NAV_DAY_REVIEW] }];
  }

  // EPIC-006 Phase 5: pure admins never see the field home.
  if (role === "admin") {
    return buildHubSections(NAV_TODAY);
  }

  // Owner: sidebar reflects the ACTIVE workspace so the two homes never sit
  // side-by-side (TASK-058 follow-up). Shared business destinations stay in both.
  const home = view === "office" ? NAV_TODAY : NAV_MY_DAY;
  return buildHubSections(home);
}

/**
 * Mobile bottom tab shortcuts. Owner/admin: 4 hubs (Home / Work / People / Money);
 * AppShell adds the More button as the 5th slot. Tech: My Day + Visits.
 */
export function getBottomNavItems(role: Role): NavItem[] {
  if (role === "tech") {
    const myDay: NavItem = { href: "/app/my-work", label: "My Day", Icon: IconMyDay };
    const visits: NavItem = { href: "/app/visits", label: "Visits", Icon: IconVisits };
    return [myDay, visits];
  }

  const home: NavItem =
    role === "owner"
      ? {
          href: "/app/my-work",
          label: "Home",
          Icon: IconMyDay,
          activePrefixes: ["/app/my-work", "/app/day-review", "/app/timeline", "/app/capture"],
        }
      : {
          href: "/app",
          label: "Home",
          Icon: IconDashboard,
          activePrefixes: ["/app/day-review", "/app/timeline", "/app/capture"],
        };

  const work: NavItem = {
    href: "/app/jobs",
    label: "Work",
    Icon: IconJobs,
    activePrefixes: [
      "/app/jobs",
      "/app/requests",
      "/app/estimates",
      "/app/work-orders",
      "/app/schedule",
      "/app/visits",
    ],
  };
  const people: NavItem = {
    href: "/app/clients",
    label: "People",
    Icon: IconClients,
    activePrefixes: ["/app/clients", "/app/properties"],
  };
  const money: NavItem = {
    href: "/app/invoices",
    label: "Money",
    Icon: IconInvoices,
    activePrefixes: ["/app/invoices", "/app/reports", "/app/expenses", "/app/materials", "/app/mileage"],
  };

  return [home, work, people, money];
}

/** Returns true if href (and optional hub prefixes) match the current pathname */
export function isNavActive(
  pathname: string,
  href: string,
  activePrefixes?: string[],
): boolean {
  if (activePrefixes?.length) {
    for (const prefix of activePrefixes) {
      if (prefix === "/app") {
        if (pathname === "/app") return true;
        continue;
      }
      if (pathname === prefix || pathname.startsWith(prefix + "/")) return true;
    }
  }
  if (href === "/app") return pathname === "/app";
  return pathname === href || pathname.startsWith(href + "/");
}

// ---------------------------------------------------------------------------
// AppShell
// ---------------------------------------------------------------------------

interface AppShellProps {
  role: Role;
  userName?: string;
  reviewPending?: boolean;
  children: ReactNode;
}

export function AppShell({ role, userName, reviewPending, children }: AppShellProps) {
  const pathname = usePathname();
  // The sidebar follows the surface you're on: My Day = field, everything else =
  // office. So Field never shows the Overview home and vice-versa.
  const sections = getNavSections(role, pathname.startsWith("/app/my-work") ? "field" : "office");
  const bottomItems = getBottomNavItems(role);
  const [showQuickLead, setShowQuickLead] = useState(false);
  const [showMore, setShowMore] = useState(false);
  const [collapsed, setCollapsed] = useState(false);
  const moreButtonRef = useRef<HTMLButtonElement>(null);
  const moreSheetRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const val = localStorage.getItem("p7-sidebar-collapsed");
    if (val === "true") {
      setCollapsed(true);
    }
  }, []);

  const toggleCollapse = () => {
    const next = !collapsed;
    setCollapsed(next);
    localStorage.setItem("p7-sidebar-collapsed", String(next));
  };

  const isAdminOrOwner = role === "owner" || role === "admin";
  // Logo goes to each role's home: My Day for field roles, the office dashboard
  // for pure admins (who get bounced there from My Day anyway).
  const homeHref = role === "admin" ? "/app" : "/app/my-work";

  const { summary: attention, refresh: refreshAttention } = useAttentionSummary(isAdminOrOwner);

  // Close the More sheet whenever navigation happens; refresh attention counts.
  useEffect(() => {
    setShowMore(false);
    if (isAdminOrOwner) void refreshAttention();
  }, [pathname, isAdminOrOwner, refreshAttention]);

  // Mobile More is a real modal navigation surface: move focus in, trap Tab,
  // support Escape, then return focus to the trigger. This preserves keyboard
  // reachability in installed/PWA mode where browser chrome may be absent.
  useEffect(() => {
    if (!showMore) return;

    const sheet = moreSheetRef.current;
    if (!sheet) return;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";

    const getFocusable = () =>
      Array.from(
        sheet.querySelectorAll<HTMLElement>(
          'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])',
        ),
      ).filter((el) => !el.hasAttribute("hidden") && el.getAttribute("aria-hidden") !== "true");

    const focusable = getFocusable();
    (focusable[0] ?? sheet).focus();

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        event.preventDefault();
        setShowMore(false);
        requestAnimationFrame(() => moreButtonRef.current?.focus());
        return;
      }
      if (event.key !== "Tab") return;

      const items = getFocusable();
      if (!items.length) {
        event.preventDefault();
        sheet.focus();
        return;
      }
      const first = items[0];
      const last = items[items.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    };

    document.addEventListener("keydown", handleKeyDown);
    return () => {
      document.removeEventListener("keydown", handleKeyDown);
      document.body.style.overflow = previousOverflow;
    };
  }, [showMore]);

  const avatarLetter = userName ? userName[0].toUpperCase() : role[0].toUpperCase();
  const displayName = userName || "Account";

  return (
    <ToastProvider>
      <LiveRefresh />
      <a className="p7-skip-link" href="#main-content">Skip to main content</a>
      <div className={`p7-layout ${collapsed ? "p7-layout-collapsed" : ""}`}>
        {/* ---- Desktop/Tablet Sidebar ---- */}
        <aside className="p7-sidebar" aria-label="Main navigation">
          {/* Brand */}
          <div style={{ position: "relative" }}>
            <Link href={homeHref as Route} className="p7-sidebar-brand">
              <div className="p7-brand-logo" aria-hidden="true">
                <span className="p7-brand-logo-text">DV</span>
              </div>
              <span className="p7-brand-name">Dovetails</span>
            </Link>
            {isAdminOrOwner && !collapsed && (
              <div style={{ position: "absolute", top: 10, right: 40, zIndex: 2 }}>
                <AttentionBell summary={attention} onChanged={() => void refreshAttention()} />
              </div>
            )}
            <button
              type="button"
              onClick={toggleCollapse}
              className="p7-sidebar-toggle-btn"
              title={collapsed ? "Expand sidebar" : "Collapse sidebar"}
              aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
            >
              {collapsed ? <IconChevronRight /> : <IconChevronLeft />}
            </button>
          </div>

          {isAdminOrOwner && <GlobalSearch />}

          {/* New Request button — owner/admin only */}
          {isAdminOrOwner && (
            <button
              type="button"
              onClick={() => setShowQuickLead(true)}
              className="p7-new-request-btn"
              style={{
                display: "flex",
                alignItems: "center",
                gap: 8,
                width: "100%",
                padding: "8px 12px",
                margin: "4px 0 8px",
                borderRadius: 6,
                border: "1px solid var(--accent, #0f172a)",
                background: "var(--accent, #0f172a)",
                color: "#fff",
                fontSize: 13,
                fontWeight: 600,
                cursor: "pointer",
                textAlign: "left",
              }}
            >
              <span style={{ fontSize: 16 }} aria-hidden="true">⚡</span>
              <span className="p7-new-request-label">New Request</span>
            </button>
          )}

          {/* Scrollable nav sections */}
          <nav className="p7-nav" aria-label="Primary navigation">
            {sections.map((section, sectionIdx) => (
              <div key={sectionIdx}>
                {section.label && <div className="p7-nav-section">{section.label}</div>}
                {section.items.map((item) => {
                  const active = isNavActive(pathname, item.href, item.activePrefixes);
                  const count =
                    item.href === NAV_REQUESTS.href
                      ? attention.requestsCount
                      : item.href === NAV_INVOICES.href
                        ? attention.invoicesCount
                        : item.href === NAV_ESTIMATES.href
                          ? attention.estimatesCount
                          : 0;
                  const href =
                    count > 0 &&
                    (item.href === NAV_REQUESTS.href ||
                      item.href === NAV_INVOICES.href ||
                      item.href === NAV_ESTIMATES.href)
                      ? (`${item.href}?attention=1` as Route)
                      : (item.href as Route);
                  const navClass = `p7-nav-item ${active ? "p7-nav-active" : ""}`;
                  const navInner = (
                    <>
                      <span className="p7-nav-icon" aria-hidden="true" style={{ position: "relative" }}>
                        <item.Icon size={18} />
                        {item.href === NAV_DAY_REVIEW.href && reviewPending && (
                          <span style={{ position: "absolute", top: -3, right: -3, width: 8, height: 8, borderRadius: "50%", background: "#ef4444", border: "1.5px solid var(--bg)" }} aria-label="Review pending" />
                        )}
                      </span>
                      <span className="p7-nav-label">{item.label}</span>
                      {item.href === NAV_DAY_REVIEW.href && reviewPending && (
                        <span className="sr-only">Review pending</span>
                      )}
                      {isAdminOrOwner && <NavCountBadge count={count} />}
                    </>
                  );
                  if (item.href === CAPTURE_HREF) {
                    return (
                      <CaptureLink
                        key={item.href}
                        className={navClass}
                        aria-current={active ? "page" : undefined}
                        title={item.label}
                        style={{ display: "flex", alignItems: "center", gap: 8 }}
                      >
                        {navInner}
                      </CaptureLink>
                    );
                  }
                  return (
                    <Link
                      key={item.href}
                      href={href}
                      className={navClass}
                      aria-current={active ? "page" : undefined}
                      title={item.label}
                      style={{ display: "flex", alignItems: "center", gap: 8 }}
                    >
                      {navInner}
                    </Link>
                  );
                })}
              </div>
            ))}
          </nav>

          {/* Footer — user chip + logout */}
          <div className="p7-sidebar-footer">
            {/* Tech sidebar nav has no Settings entry — surface it here so the
                profile + sign out are reachable on desktop too (EPIC-006 P5). */}
            {role === "tech" && (
              <Link
                href={"/app/settings" as Route}
                className={`p7-nav-item ${isNavActive(pathname, "/app/settings") ? "p7-nav-active" : ""}`}
                title="Settings"
                style={{ marginBottom: "var(--space-2)" }}
              >
                <span className="p7-nav-icon" aria-hidden="true"><IconSettings size={18} /></span>
                <span className="p7-nav-label">Settings</span>
              </Link>
            )}
            <div style={{ display: "flex", flexDirection: "column", gap: "var(--space-2)", width: "100%" }}>
              <div className="p7-user-chip" title={displayName}>
                <div className="p7-user-avatar" aria-hidden="true">
                  {avatarLetter}
                </div>
                <div className="p7-user-info">
                  <span className="p7-user-name">{displayName}</span>
                  <span className="p7-user-role">{role}</span>
                </div>
              </div>
              <LogoutButton />
            </div>
          </div>
        </aside>

        {/* ---- Main content ---- */}
        <main className="p7-main" id="main-content" tabIndex={-1}>
          {/* TASK-058: workspace mode is automatic by device (phone → Field,
              tablet/computer → Office) with an override in Settings — no on-screen
              toggle or daily popup. This renders nothing; it only steers entry. */}
          {role === "owner" && <WorkspaceAutoRoute />}
          <ConnectionStatus />
          {children}
        </main>

        {/* ---- Mobile bottom tab bar ---- */}
        <nav className="p7-bottom-nav" aria-label="Mobile navigation">
          <div className="p7-bottom-nav-inner">
            {bottomItems.map((item) => {
              const active = isNavActive(pathname, item.href, item.activePrefixes);
              return (
                <Link
                  key={`${item.label}-${item.href}`}
                  href={item.href as Route}
                  className={`p7-bottom-nav-item ${active && !showMore ? "p7-nav-active" : ""}`}
                  aria-current={active ? "page" : undefined}
                >
                  <span className="p7-bottom-nav-icon" aria-hidden="true">
                    <item.Icon size={20} />
                  </span>
                  <span>{item.label}</span>
                </Link>
              );
            })}
            {/* EPIC-006 Phase 5: every role gets the More sheet so Settings and
                Sign out are reachable on a phone (sidebar is hidden < 768px). */}
            {(
              <button
                ref={moreButtonRef}
                type="button"
                className={`p7-bottom-nav-item p7-more-btn ${showMore ? "p7-nav-active" : ""}`}
                aria-label={showMore ? "Close all destinations" : "Open all destinations"}
                aria-expanded={showMore}
                aria-controls="p7-more-sheet"
                onClick={() => setShowMore((v) => !v)}
              >
                <span className="p7-bottom-nav-icon" aria-hidden="true">
                  <svg width="20" height="20" viewBox="0 0 24 24" aria-hidden="true">
                    <circle cx="5" cy="12" r="1.8" fill="currentColor" />
                    <circle cx="12" cy="12" r="1.8" fill="currentColor" />
                    <circle cx="19" cy="12" r="1.8" fill="currentColor" />
                  </svg>
                </span>
                <span>More</span>
              </button>
            )}
          </div>
        </nav>

        {/* ---- Mobile "More" sheet — the complete nav on a phone ---- */}
        {showMore && (
          <>
            <div
              className="p7-more-overlay"
              aria-hidden="true"
              onClick={() => {
                setShowMore(false);
                requestAnimationFrame(() => moreButtonRef.current?.focus());
              }}
            />
            <div
              ref={moreSheetRef}
              id="p7-more-sheet"
              className="p7-more-sheet"
              role="dialog"
              aria-modal="true"
              aria-label="All destinations"
              tabIndex={-1}
            >
              <div className="p7-more-sheet-header">
                <strong>All destinations</strong>
                <button
                  type="button"
                  className="p7-more-close"
                  onClick={() => {
                    setShowMore(false);
                    requestAnimationFrame(() => moreButtonRef.current?.focus());
                  }}
                  aria-label="Close all destinations"
                >
                  ×
                </button>
              </div>
              {isAdminOrOwner && (
                <div style={{ display: "flex", justifyContent: "flex-end", padding: "8px 12px 0" }}>
                  <AttentionBell summary={attention} onChanged={() => void refreshAttention()} />
                </div>
              )}
              <div className="p7-more-sections">
                {sections.map((section, sectionIdx) => (
                  <div key={sectionIdx} className="p7-more-section">
                    {section.label ? (
                      <div className="p7-more-section-label">{section.label}</div>
                    ) : null}
                    <div className="p7-more-grid">
                      {section.items.map((item) => {
                        const active = isNavActive(pathname, item.href, item.activePrefixes);
                        const count =
                          item.href === NAV_REQUESTS.href
                            ? attention.requestsCount
                            : item.href === NAV_INVOICES.href
                              ? attention.invoicesCount
                              : item.href === NAV_ESTIMATES.href
                                ? attention.estimatesCount
                                : 0;
                        const href =
                          count > 0 &&
                          (item.href === NAV_REQUESTS.href ||
                            item.href === NAV_INVOICES.href ||
                            item.href === NAV_ESTIMATES.href)
                            ? (`${item.href}?attention=1` as Route)
                            : (item.href as Route);
                        const moreClass = `p7-more-item ${active ? "p7-nav-active" : ""}`;
                        const moreInner = (
                          <>
                            <span className="p7-nav-icon" aria-hidden="true" style={{ position: "relative" }}>
                              <item.Icon size={20} />
                              {item.href === NAV_DAY_REVIEW.href && reviewPending && (
                                <span style={{ position: "absolute", top: -3, right: -3, width: 8, height: 8, borderRadius: "50%", background: "#ef4444", border: "1.5px solid var(--bg)" }} />
                              )}
                              {isAdminOrOwner && count > 0 && (
                                <span
                                  style={{
                                    position: "absolute",
                                    top: -6,
                                    right: -8,
                                    minWidth: 16,
                                    height: 16,
                                    padding: "0 4px",
                                    borderRadius: 999,
                                    background: "#dc2626",
                                    color: "#fff",
                                    fontSize: 10,
                                    fontWeight: 700,
                                    display: "inline-flex",
                                    alignItems: "center",
                                    justifyContent: "center",
                                  }}
                                >
                                  {count > 99 ? "99+" : count}
                                </span>
                              )}
                            </span>
                            <span>{item.label}</span>
                            {item.href === NAV_DAY_REVIEW.href && reviewPending && (
                              <span className="sr-only">Review pending</span>
                            )}
                          </>
                        );
                        if (item.href === CAPTURE_HREF) {
                          return (
                            <CaptureLink
                              key={item.href}
                              className={moreClass}
                              aria-current={active ? "page" : undefined}
                              onClick={() => setShowMore(false)}
                            >
                              {moreInner}
                            </CaptureLink>
                          );
                        }
                        return (
                          <Link
                            key={item.href}
                            href={href}
                            className={moreClass}
                            aria-current={active ? "page" : undefined}
                            onClick={() => setShowMore(false)}
                          >
                            {moreInner}
                          </Link>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
              <div className="p7-more-footer">
                <div className="p7-user-chip">
                  <div className="p7-user-avatar" aria-hidden="true">{avatarLetter}</div>
                  <div className="p7-user-info">
                    <span className="p7-user-name">{displayName}</span>
                    <span className="p7-user-role">{role}</span>
                  </div>
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: "var(--space-2)" }}>
                  <Link
                    href={"/app/settings" as Route}
                    className="p7-nav-item"
                    style={{ padding: "6px 10px", fontSize: 13 }}
                    onClick={() => setShowMore(false)}
                  >
                    <span className="p7-nav-icon" aria-hidden="true"><IconSettings size={18} /></span>
                    <span className="p7-nav-label">Settings</span>
                  </Link>
                  <LogoutButton />
                </div>
              </div>
            </div>
          </>
        )}
      </div>
      {showQuickLead && <QuickLeadModal onClose={() => setShowQuickLead(false)} />}
      {isAdminOrOwner &&
        !pathname.startsWith("/app/my-work") &&
        !pathname.startsWith("/app/capture") && <FloatingActionButton />}
    </ToastProvider>
  );
}

// ---------------------------------------------------------------------------
// Logout button
// ---------------------------------------------------------------------------

function LogoutButton() {
  const [pending, setPending] = useState(false);

  async function handleLogout() {
    setPending(true);
    try {
      await fetch("/api/v1/auth/logout", { method: "POST" });
      window.location.href = "/login";
    } catch {
      setPending(false);
    }
  }

  return (
    <button
      type="button"
      onClick={handleLogout}
      disabled={pending}
      className="p7-logout-btn"
      aria-label="Sign out"
      title="Sign out"
    >
      {pending ? "…" : "Sign out"}
    </button>
  );
}
