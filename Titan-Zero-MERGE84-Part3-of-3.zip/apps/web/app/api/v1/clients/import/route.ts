import { randomUUID } from "crypto";
import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { withAuth } from "../../../../../lib/auth/middleware";
import type { AuthSession } from "../../../../../lib/auth/middleware";
import { withPortableTransaction } from "../../../../../lib/db/portable";
import { normalizeClientName } from "../../../../../lib/crm/normalization";
import { logger } from "../../../../../lib/logger";

export const dynamic = "force-dynamic";

const nullableStr = (max: number) => z.string().max(max).optional().or(z.literal("")).transform((v) => v || null);
const nullableDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional().or(z.literal("")).transform((v) => v || null);

const rowSchema = z.object({
  name: z.string().min(1).max(255), nickname: nullableStr(255),
  email: z.string().email().optional().or(z.literal("")).transform((v) => v || null), phone: nullableStr(50), company_name: nullableStr(255),
  address_line1: nullableStr(500), address_line2: nullableStr(500), city: nullableStr(100), state: nullableStr(100), zip: nullableStr(20),
  notes: z.string().optional().or(z.literal("")).transform((v) => v || null), birthday: nullableDate, square_customer_id: nullableStr(128),
  creation_source: nullableStr(64), first_visit_at: nullableDate, last_visit_at: nullableDate,
  transaction_count: z.number().int().nonnegative().optional().default(0), lifetime_spend_cents: z.number().int().nonnegative().optional().default(0),
  email_subscription_status: nullableStr(64), instant_profile: z.boolean().optional().default(false),
});

export const POST = withAuth(async (request: NextRequest, session: AuthSession) => {
  if (session.role === "tech") return NextResponse.json({ error: { code: "FORBIDDEN", message: "Not allowed" } }, { status: 403 });

  let rows: unknown[];
  try { const body = await request.json(); rows = Array.isArray(body.rows) ? body.rows : []; }
  catch { return NextResponse.json({ error: { code: "BAD_REQUEST", message: "Invalid JSON" } }, { status: 400 }); }
  if (!rows.length) return NextResponse.json({ error: { code: "BAD_REQUEST", message: "No rows provided" } }, { status: 400 });
  if (rows.length > 1000) return NextResponse.json({ error: { code: "BAD_REQUEST", message: "Max 1000 rows per import" } }, { status: 400 });

  const parsed: z.infer<typeof rowSchema>[] = []; const parseErrors: { row: number; message: string }[] = [];
  rows.forEach((row, i) => { const result = rowSchema.safeParse(row); result.success ? parsed.push(result.data) : parseErrors.push({ row: i + 1, message: result.error.issues.map((e) => `${e.path.join(".")}: ${e.message}`).join("; ") }); });
  if (parseErrors.length) return NextResponse.json({ error: { code: "VALIDATION_ERROR", message: "Some rows are invalid", details: parseErrors } }, { status: 422 });

  let imported = 0; let updated = 0; const skipped = 0;
  try {
    await withPortableTransaction(async (client) => {
      for (const row of parsed) {
        const exists = row.square_customer_id
          ? await client.query<{ id: string }>(`SELECT id FROM clients WHERE account_id = $1 AND square_customer_id = $2`, [session.accountId, row.square_customer_id])
          : await client.query<{ id: string }>(`SELECT id FROM clients WHERE account_id = $1 AND LOWER(name) = LOWER($2) AND LOWER(COALESCE(email,'')) = LOWER(COALESCE($3,''))`, [session.accountId, row.name, row.email ?? ""]);
        if (exists.rows.length) {
          await client.query(
            `UPDATE clients SET nickname=COALESCE($2,nickname), email=COALESCE($3,email), phone=COALESCE($4,phone), company_name=COALESCE($5,company_name),
             address_line1=COALESCE($6,address_line1), address_line2=COALESCE($7,address_line2), city=COALESCE($8,city), state=COALESCE($9,state), zip=COALESCE($10,zip),
             notes=COALESCE($11,notes), birthday=COALESCE($12,birthday), square_customer_id=COALESCE($13,square_customer_id), creation_source=COALESCE($14,creation_source),
             first_visit_at=COALESCE($15,first_visit_at), last_visit_at=COALESCE($16,last_visit_at), transaction_count=GREATEST(COALESCE($17,0),COALESCE(transaction_count,0)),
             lifetime_spend_cents=GREATEST(COALESCE($18,0),COALESCE(lifetime_spend_cents,0)), email_subscription_status=COALESCE($19,email_subscription_status),
             instant_profile=COALESCE($20,instant_profile), updated_at=CURRENT_TIMESTAMP WHERE id=$1 AND account_id=$21`,
            [exists.rows[0].id,row.nickname,row.email,row.phone,row.company_name,row.address_line1,row.address_line2,row.city,row.state,row.zip,row.notes,row.birthday,row.square_customer_id,row.creation_source,row.first_visit_at,row.last_visit_at,row.transaction_count,row.lifetime_spend_cents,row.email_subscription_status,row.instant_profile,session.accountId],
          ); updated++; continue;
        }
        await client.query(
          `INSERT INTO clients (id,account_id,name,nickname,email,phone,company_name,address_line1,address_line2,city,state,zip,notes,birthday,square_customer_id,creation_source,first_visit_at,last_visit_at,transaction_count,lifetime_spend_cents,email_subscription_status,instant_profile)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22)`,
          [randomUUID(),session.accountId,normalizeClientName(row.name),row.nickname,row.email,row.phone,row.company_name,row.address_line1,row.address_line2,row.city,row.state,row.zip,row.notes,row.birthday,row.square_customer_id,row.creation_source,row.first_visit_at,row.last_visit_at,row.transaction_count,row.lifetime_spend_cents,row.email_subscription_status,row.instant_profile],
        ); imported++;
      }
    });
    return NextResponse.json({ data: { imported, updated, skipped } });
  } catch (err) {
    logger.error("[clients/import]", err); return NextResponse.json({ error: { code: "INTERNAL_ERROR", message: "Import failed" } }, { status: 500 });
  }
});
