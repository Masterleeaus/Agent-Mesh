/**
 * Materials catalog learn helpers — upsert last/avg paid from receipt lines.
 * Spec: docs/superpowers/specs/2026-07-31-materials-catalog-receipt-learning-design.md
 */
import type { DbClient, DatabaseDialect } from "@/lib/db-contract";
import { buildMaterialCatalogSql } from "./catalog-sql";

export type CatalogLineInput = {
  name: string;
  unit_cost_cents: number;
  sku?: string | null;
  quantity?: number;
  unit?: string;
};

export type CatalogLearnContext = {
  accountId: string;
  supplier?: string | null;
  purchasedAt?: string | null; // YYYY-MM-DD
  category?: string;
};

export type MaterialsPriceBookRow = {
  id: string;
  account_id: string;
  name: string;
  brand: string | null;
  category: string;
  unit: string;
  unit_cost_cents: number;
  supplier: string | null;
  sku: string | null;
  last_purchased_at: string | null;
  notes: string | null;
  is_active: boolean;
  avg_paid_cents: number | null;
  purchase_count: number;
};

/** Running average after incorporating one new unit cost. */
export function computeRunningAverage(
  prevAvgCents: number | null | undefined,
  prevCount: number,
  newCostCents: number,
): { avg_paid_cents: number; purchase_count: number } {
  const cost = Math.round(newCostCents);
  if (prevCount <= 0 || prevAvgCents == null || prevAvgCents < 0) {
    return { avg_paid_cents: cost, purchase_count: 1 };
  }
  const nextCount = prevCount + 1;
  const avg = Math.round((prevAvgCents * prevCount + cost) / nextCount);
  return { avg_paid_cents: avg, purchase_count: nextCount };
}

/**
 * Whether an incoming observation should overwrite "last paid" fields.
 * null incoming date always updates (treat as latest observation).
 * Otherwise update only when at least as recent as the stored last purchase.
 */
export function shouldUpdateLastPaid(
  existingLastPurchasedAt: string | null | undefined,
  incomingPurchasedAt: string | null | undefined,
): boolean {
  if (!incomingPurchasedAt) return true;
  if (!existingLastPurchasedAt) return true;
  const existing = existingLastPurchasedAt.slice(0, 10);
  const incoming = incomingPurchasedAt.slice(0, 10);
  return incoming >= existing;
}

function normalizeSku(sku: string | null | undefined): string | null {
  const s = sku?.trim() ?? "";
  return s.length > 0 ? s : null;
}

function normalizeName(name: string): string {
  return name.trim();
}

const VALID_CATEGORIES = new Set([
  "paint",
  "lumber",
  "hardware",
  "concrete",
  "fasteners",
  "sheet_goods",
  "trim",
  "flooring",
  "other",
]);

function normalizeCategory(category?: string): string {
  if (category && VALID_CATEGORIES.has(category)) return category;
  return "other";
}

/**
 * Upsert a single catalog row from a purchase observation.
 * Match: SKU first (active rows), else lower(name)+unit.
 */
export async function upsertMaterialFromPurchase(
  client: DbClient,
  ctx: CatalogLearnContext,
  line: CatalogLineInput,
  dialect: DatabaseDialect = "postgres",
): Promise<MaterialsPriceBookRow | null> {
  const sql = buildMaterialCatalogSql(dialect);
  const name = normalizeName(line.name);
  const unitCost = Math.round(line.unit_cost_cents);
  if (!name || unitCost <= 0) return null;

  const sku = normalizeSku(line.sku);
  const unit = (line.unit?.trim() || "each").slice(0, 50);
  const category = normalizeCategory(ctx.category);
  const supplier = ctx.supplier?.trim() || null;
  const purchasedAt = ctx.purchasedAt?.slice(0, 10) || null;

  let existing: MaterialsPriceBookRow | null = null;

  if (sku) {
    const bySku = await client.query<MaterialsPriceBookRow>(sql.findBySku, [ctx.accountId, sku]);
    existing = bySku.rows[0] ?? null;
  }

  if (!existing) {
    const byName = await client.query<MaterialsPriceBookRow>(sql.findByName, [ctx.accountId, name, unit]);
    existing = byName.rows[0] ?? null;
  }

  if (existing) {
    const { avg_paid_cents, purchase_count } = computeRunningAverage(
      existing.avg_paid_cents,
      existing.purchase_count,
      unitCost,
    );
    const updateLast = shouldUpdateLastPaid(existing.last_purchased_at, purchasedAt);
    const nextUnitCost = updateLast ? unitCost : existing.unit_cost_cents;
    const nextLastPurchased = updateLast
      ? purchasedAt ?? existing.last_purchased_at
      : existing.last_purchased_at;
    const updated = await client.query<MaterialsPriceBookRow>(
      sql.update,
      [existing.id, nextUnitCost, avg_paid_cents, purchase_count, sku, supplier, nextLastPurchased, name, ctx.accountId],
    );
    if (dialect === "postgres") return updated.rows[0] ?? null;
    const refreshed = await client.query<MaterialsPriceBookRow>(sql.selectById, [existing.id, ctx.accountId]);
    return refreshed.rows[0] ?? null;
  }

  const inserted = await client.query<MaterialsPriceBookRow>(
    sql.insert,
    [ctx.accountId, name, category, unit, unitCost, supplier, sku, purchasedAt],
  );
  if (dialect === "postgres") return inserted.rows[0] ?? null;
  const refreshed = await client.query<MaterialsPriceBookRow>(sql.selectByNaturalKey, [ctx.accountId, name, unit]);
  return refreshed.rows[0] ?? null;
}

/**
 * Learn catalog prices from a batch of expense line items.
 * Returns how many rows were upserted (skips invalid lines).
 */
export async function learnMaterialsFromLineItems(
  client: DbClient,
  ctx: CatalogLearnContext,
  lines: CatalogLineInput[],
  dialect: DatabaseDialect = "postgres",
): Promise<{ learned: number }> {
  let learned = 0;
  for (const line of lines) {
    const row = await upsertMaterialFromPurchase(client, ctx, line, dialect);
    if (row) learned += 1;
  }
  return { learned };
}
