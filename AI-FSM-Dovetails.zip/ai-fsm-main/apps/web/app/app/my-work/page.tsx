import Link from "next/link";
import type { Route } from "next";
import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth/session";
import { queryForSession } from "@/lib/db";
import { formatVisitTime, isSameCalendarDay } from "@/lib/visits/formatting";
import { formatBusinessDateTime } from "@/lib/time/business-tz";
import { pickHeroVisit, type HeroVisit } from "@/lib/my-day/visit-hero";
import { loadFieldDayData } from "@/lib/my-work/field-day-data";
import {
  loadPendingArrivalProposals,
  loadOpenWorkOrdersForProperties,
} from "@/lib/field/load-arrival-proposals";
import { MyDayMobileLayout } from "../my-day/MyDayMobileLayout";
import { ManualSiteVisitButton } from "../ManualSiteVisitButton";
import { LocationCaptureControl } from "../LocationCaptureControl";
import { ArrivalProposalBanner } from "@/components/field/ArrivalProposalBanner";
import { Suspense } from "react";
import {
  OPERATIONAL_VISIT_TYPES,
  WORK_ORDER_STATUS_LABELS,
  VISIT_TYPE_LABELS,
  type WorkOrderStatus,
  type VisitType,
} from "@ai-fsm/domain";
import { PageContainer, PageHeader, Card, SectionHeader, EmptyState, LinkButton } from "@/components/ui";
import { loadNeedsAttention } from "@/lib/attention/load-needs-attention";
import { NeedsAttentionPanel } from "../NeedsAttentionPanel";
import { TodayTimeline } from "./TodayTimeline";
import { todayEmptyCopy, todayJobCountLabel, todayJobsHeading } from "./today-list";
import { filterAttentionForSurface } from "@/lib/attention/surfaces";

export const dynamic = "force-dynamic";

type PageProps = {
  searchParams: Promise<{ promises?: string }>;
};

type WoCard = {
  id: string;
  job_id: string;
  title: string;
  status: string;
  client_name: string | null;
  property_address: string | null;
  next_scheduled: string | null;
  active_visit_id: string | null;
};

type AssessmentCard = {
  id: string;
  visit_type: string;
  scheduled_start: string;
  status: string;
  client_name: string | null;
  job_title: string | null;
};

export default async function MyWorkPage({ searchParams }: PageProps) {
  const session = await getSession();
  if (!session) redirect("/login");
  if (session.role === "admin") redirect("/app");
  const { promises: promisesParam } = await searchParams;

  const isTech = session.role === "tech";
  const isOwner = session.role === "owner";
  const opTypes = [...OPERATIONAL_VISIT_TYPES];
  const now = new Date();

  const [fieldDay, workOrders, assessments, heroVisits, proposals] = await Promise.all([
    loadFieldDayData(session, isOwner),
    queryForSession<WoCard>(
      session,
      `SELECT w.id, w.job_id::text, w.title, w.status, c.name AS client_name, p.address AS property_address,
              (SELECT MIN(v.scheduled_start)::text FROM visits v
               WHERE v.work_order_id = w.id AND v.status = 'scheduled' AND v.scheduled_start > now()) AS next_scheduled,
              (SELECT v.id::text FROM visits v
               WHERE v.work_order_id = w.id AND v.assigned_user_id = $2
                 AND v.status IN ('dispatched','traveling','arrived','in_progress','waiting')
               LIMIT 1) AS active_visit_id
       FROM work_orders w
       JOIN jobs j ON j.id = w.job_id
       LEFT JOIN clients c ON c.id = w.client_id
       LEFT JOIN properties p ON p.id = j.property_id
       WHERE w.account_id = $1 AND w.assigned_user_id = $2
         AND w.status NOT IN ('draft','completed','cancelled')
       ORDER BY
         CASE w.status WHEN 'dispatched' THEN 0 WHEN 'scheduled' THEN 1 WHEN 'waiting' THEN 2 ELSE 3 END,
         next_scheduled NULLS LAST,
         w.updated_at DESC`,
      [session.accountId, session.userId],
    ),
    queryForSession<AssessmentCard>(
      session,
      `SELECT v.id, v.visit_type, v.scheduled_start::text, v.status,
              c.name AS client_name, j.title AS job_title
       FROM visits v
       LEFT JOIN jobs j ON j.id = v.job_id
       LEFT JOIN clients c ON c.id = j.client_id
       WHERE v.account_id = $1 AND v.assigned_user_id = $2
         AND v.work_order_id IS NULL
         AND v.visit_type = ANY($3::text[])
         AND v.status NOT IN ('completed','cancelled')
       ORDER BY v.scheduled_start ASC
       LIMIT 50`,
      [session.accountId, session.userId, opTypes],
    ),
    queryForSession<HeroVisit>(
      session,
      `SELECT v.id, v.status, v.scheduled_start::text, j.id::text AS job_id, j.title AS job_title,
              p.address AS property_address, c.name AS client_name, c.phone AS client_phone,
              (SELECT t.label FROM visit_tasks vt
               JOIN work_order_tasks t ON t.id = vt.task_id
               WHERE vt.visit_id = v.id AND vt.account_id = v.account_id
                 AND t.completed = false AND t.status <> 'done'
               ORDER BY t.sort_order ASC LIMIT 1) AS first_up
       FROM visits v
       LEFT JOIN jobs j ON j.id = v.job_id
       LEFT JOIN clients c ON c.id = j.client_id
       LEFT JOIN properties p ON p.id = j.property_id
       WHERE v.account_id = $1 AND v.assigned_user_id = $2
         AND v.status NOT IN ('completed','cancelled')
       ORDER BY v.scheduled_start ASC
       LIMIT 100`,
      [session.accountId, session.userId],
    ),
    loadPendingArrivalProposals(session),
  ]);

  const propIds = [
    ...new Set(
      proposals.map((p) => p.propertyId).filter((id): id is string => !!id),
    ),
  ];
  const openWorkOrdersByProperty = await loadOpenWorkOrdersForProperties(
    session,
    propIds,
  );

  const todayVisits = heroVisits.filter((v) => isSameCalendarDay(v.scheduled_start));
  const heroVisit = pickHeroVisit(todayVisits, now.getTime());
  const needsAttentionRaw = isOwner ? await loadNeedsAttention(session) : null;
  const needsAttention = needsAttentionRaw
    ? { items: filterAttentionForSurface(needsAttentionRaw.items, "today"), openPromiseRows: [] as typeof needsAttentionRaw.openPromiseRows }
    : null;

  const nowHour = now.getHours();
  const greeting =
    nowHour < 12 ? "Good morning" : nowHour < 17 ? "Good afternoon" : "Good evening";

  let statusLabel = todayJobCountLabel(workOrders.length);
  if (heroVisit?.status === "in_progress" || heroVisit?.status === "arrived") {
    statusLabel += " · In progress now";
  } else if (heroVisit) {
    const d = new Date(heroVisit.scheduled_start);
    statusLabel += ` · ${formatVisitTime(heroVisit.scheduled_start).toLowerCase()} next`;
  }

  return (
    <PageContainer>
      <PageHeader
        title="Today"
        subtitle={`${greeting} — ${statusLabel}`}
        actions={
          isTech ? (
            <LinkButton href="/app/visits" variant="secondary" size="sm">
              Visits →
            </LinkButton>
          ) : (
            <span style={{ display: "inline-flex", gap: "var(--space-2)", flexWrap: "wrap" }}>
              <LinkButton href={"/app/timeline" as Route} variant="ghost" size="sm">
                Vehicle tracking
              </LinkButton>
              <ManualSiteVisitButton />
              <span className="p7-only-desktop">
                <LinkButton href="/app" variant="secondary" size="sm">
                  ← Desk
                </LinkButton>
              </span>
            </span>
          )
        }
      />

      {proposals.length > 0 && (() => {
        const active = fieldDay.activityEntries?.find((e) => e.ended_at === null) ?? null;
        const top = proposals[0];
        const alreadyOnSiteWork =
          !!active &&
          (active.activity_type === "job_work" || active.activity_type === "estimate_visit") &&
          !!(
            (top?.workOrderId &&
              active.entity_type === "work_order" &&
              active.entity_id === top.workOrderId) ||
            (top?.visitId &&
              active.entity_type === "visit" &&
              active.entity_id === top.visitId)
          );
        return (
          <Suspense fallback={null}>
            <ArrivalProposalBanner
              proposals={proposals}
              openWorkOrdersByProperty={openWorkOrdersByProperty}
              activityType={active?.activity_type ?? null}
              alreadyOnSiteWork={alreadyOnSiteWork}
            />
          </Suspense>
        );
      })()}

      {fieldDay.locationSettings && (
        <div style={{ marginBottom: "var(--space-4)" }}>
          <LocationCaptureControl
            enabled={fieldDay.locationSettings.enabled}
            pausedUntil={fieldDay.locationSettings.pausedUntil}
            hasActiveWorkday={!!fieldDay.openSession}
            showTrackingLink={!isTech}
          />
        </div>
      )}

      <MyDayMobileLayout
        openSession={fieldDay.openSession}
        vehicles={fieldDay.vehicles}
        activityEntries={fieldDay.activityEntries}
        dayMileage={fieldDay.dayMileage}
        heroVisit={heroVisit}
        clockedIn={fieldDay.clockedIn}
        hasParkProposal={proposals.length > 0}
        currentJobId={heroVisit?.job_id ?? workOrders.find((w) => w.active_visit_id)?.job_id ?? workOrders[0]?.job_id ?? null}
        canCapture={isOwner}
        canQuickBook={isOwner}
      >
        {needsAttention && (
          <NeedsAttentionPanel
            items={needsAttention.items}
            openPromiseRows={needsAttention.openPromiseRows}
            promisesParam={promisesParam}
          />
        )}
        <TodayTimeline
          entries={
            isTech
              ? fieldDay.activityEntries.filter((e) => e.user_id === session.userId)
              : fieldDay.activityEntries
          }
          showTrackingLink={!isTech}
        />
        <Card style={{ marginBottom: "var(--space-4)" }}>
          <SectionHeader title={todayJobsHeading()} count={workOrders.length} />
          {workOrders.length === 0 ? (
            <EmptyState
              title={todayEmptyCopy().title}
              description={todayEmptyCopy().description}
            />
          ) : (
            <ul style={{ listStyle: "none", margin: 0, padding: 0 }}>
              {workOrders.map((wo) => {
                const status =
                  WORK_ORDER_STATUS_LABELS[wo.status as WorkOrderStatus] ?? wo.status;
                const derived = wo.active_visit_id ? " · In progress" : "";
                return (
                  <li key={wo.id} style={{ borderBottom: "1px solid var(--border)" }}>
                    <Link
                      href={`/app/my-work/${wo.id}` as Route}
                      style={{
                        display: "block",
                        padding: "var(--space-3) 0",
                        textDecoration: "none",
                        color: "inherit",
                      }}
                    >
                      <strong>{wo.client_name ?? "Client"}</strong>
                      <div>{wo.title}</div>
                      <small style={{ color: "var(--fg-muted)" }}>
                        {status}
                        {derived}
                        {wo.next_scheduled &&
                          ` · Next ${formatBusinessDateTime(wo.next_scheduled)}`}
                      </small>
                    </Link>
                  </li>
                );
              })}
            </ul>
          )}
        </Card>

        {assessments.length > 0 && (
          <Card>
            <SectionHeader title="Assessments" count={assessments.length} />
            <ul style={{ listStyle: "none", margin: 0, padding: 0 }}>
              {assessments.map((v) => (
                <li key={v.id} style={{ borderBottom: "1px solid var(--border)" }}>
                  <Link
                    href={`/app/visits/${v.id}` as Route}
                    style={{
                      display: "block",
                      padding: "var(--space-3) 0",
                      textDecoration: "none",
                      color: "inherit",
                    }}
                  >
                    <strong>{v.client_name ?? v.job_title ?? "Assessment"}</strong>
                    <div>
                      {VISIT_TYPE_LABELS[v.visit_type as VisitType] ?? v.visit_type}
                    </div>
                    <small style={{ color: "var(--fg-muted)" }}>
                      {formatBusinessDateTime(v.scheduled_start)}
                    </small>
                  </Link>
                </li>
              ))}
            </ul>
          </Card>
        )}
      </MyDayMobileLayout>
    </PageContainer>
  );
}